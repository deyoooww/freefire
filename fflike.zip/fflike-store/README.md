# FFLIKE STORE

Website layanan like Free Fire — paket gratis (45 like) dan paket berbayar
dengan pembayaran QRIS otomatis, order tracking, fulfillment abstraction,
dan admin dashboard. Dibangun dengan Next.js (App Router) + Supabase
(PostgreSQL).

## Status jujur tentang "siap production"

Kode ini **bukan demo** — semua flow (order, payment, webhook, fulfillment,
admin) diimplementasikan dengan arsitektur production: validasi server-side,
idempotency, verifikasi signature, audit log, dan tidak ada status yang
di-fake. Tapi tiga hal **hanya akan benar-benar berfungsi setelah kamu
mengisi environment variables dengan kredensial asli**:

1. **Payment gateway** (Midtrans/Xendit) — tanpa `PAYMENT_API_KEY` yang
   valid, `/api/payment/create` akan mengembalikan error yang jelas, bukan
   QRIS palsu.
2. **Fulfillment API** — sistem pengiriman like sebenarnya berada di luar
   proyek ini (kamu yang punya/operasikan). Tanpa `FULFILLMENT_API_URL` dan
   `FULFILLMENT_API_KEY`, order akan ditandai `FAILED` dengan pesan error
   yang jelas — tidak pernah ditandai `COMPLETED` secara palsu.
3. **Supabase** — tanpa kredensial database, tidak ada API yang akan
   berfungsi.

## Struktur proyek

```
app/
  page.js                     Homepage
  checkout/[productId]/       Form pemesanan paket berbayar
  order/                      Pencarian & detail status pesanan
  admin/                      Dashboard admin (dilindungi auth)
  api/                        Semua API route (lihat di bawah)
components/                   Komponen UI
lib/                          Logic non-UI: auth, payment, fulfillment, validators
supabase/schema.sql           Skema database lengkap + seed produk default
```

## API Routes

| Method | Path | Keterangan |
|---|---|---|
| GET | `/api/products` | Daftar produk aktif (publik) |
| POST | `/api/orders` | Buat order paket berbayar |
| GET | `/api/orders/[orderId]` | Lihat status order |
| POST | `/api/free/claim` | Klaim 45 like gratis (dengan anti-abuse) |
| POST | `/api/payment/create` | Buat sesi QRIS untuk order |
| POST | `/api/payment/webhook` | Endpoint webhook payment gateway |
| POST | `/api/admin/login` | Login admin |
| GET | `/api/admin/stats` | Statistik dashboard |
| GET | `/api/admin/orders` | Daftar order (search/filter/sort) |
| GET/PATCH | `/api/admin/orders/[id]` | Detail & update status order |
| POST | `/api/admin/orders/[id]/retry` | Retry fulfillment |
| GET/POST | `/api/admin/products` | Daftar & buat produk |
| PATCH/DELETE | `/api/admin/products/[id]` | Update / nonaktifkan produk |

## Setup lokal

```bash
npm install
cp .env.example .env.local
# isi .env.local, lihat bagian "Environment variables" di bawah
npm run dev
```

## 1. Setup Supabase

1. Buat project baru di https://supabase.com.
2. Buka **SQL Editor**, jalankan seluruh isi `supabase/schema.sql`.
3. Ambil `SUPABASE_URL`, `SUPABASE_ANON_KEY`, dan `SUPABASE_SERVICE_ROLE_KEY`
   dari **Project Settings → API**, masukkan ke `.env.local`.
4. `SUPABASE_SERVICE_ROLE_KEY` **hanya** dipakai di server (route handlers) —
   jangan pernah expose ke client.

## 2. Setup admin

Admin tidak disimpan hardcode. Generate hash password:

```bash
node -e "console.log(require('bcryptjs').hashSync('password-kamu', 10))"
```

Isi di `.env.local`:

```
ADMIN_USERNAME=admin
ADMIN_PASSWORD_HASH=<hasil hash di atas>
ADMIN_SESSION_SECRET=<string acak panjang, minimal 32 karakter>
```

Login di `/admin/login`.

## 3. Setup payment gateway (QRIS)

Pilih salah satu provider dan isi env:

**Midtrans**
```
PAYMENT_PROVIDER=midtrans
PAYMENT_API_KEY=<Server Key dari dashboard Midtrans>
PAYMENT_IS_PRODUCTION=false   # true setelah live
```
Webhook URL yang didaftarkan di dashboard Midtrans:
`https://domain-kamu.com/api/payment/webhook`

**Xendit**
```
PAYMENT_PROVIDER=xendit
PAYMENT_API_KEY=<Secret Key dari dashboard Xendit>
PAYMENT_WEBHOOK_SECRET=<Callback Verification Token dari dashboard Xendit>
```
Webhook URL yang sama, didaftarkan di dashboard Xendit.

Untuk menambah provider lain (Tripay, Duitku, dst), buat file baru di
`lib/payment/` yang mengekspor object dengan method `createQrisPayment`,
`verifyWebhookSignature`, dan `parseWebhookEvent` (lihat
`lib/payment/midtrans.js` sebagai contoh), lalu daftarkan di
`lib/payment/index.js`. Tidak ada route handler yang perlu diubah.

## 4. Setup fulfillment API

Proyek ini **tidak** menyertakan bot/engine pengirim like — itu sistem
terpisah yang kamu operasikan sendiri. `lib/fulfillment.js` memanggilnya
lewat kontrak HTTP generik:

```
POST {FULFILLMENT_API_URL}
Headers: Authorization: Bearer {FULFILLMENT_API_KEY}
Body: { orderId, uid, nickname, quantity, idempotencyKey }
Response 200: { success: true, reference: "..." }
```

## 5. Deploy ke Vercel

1. Push project ini ke GitHub.
2. Import ke Vercel, framework preset otomatis terdeteksi sebagai Next.js.
3. Tambahkan semua env var dari `.env.example` di **Project Settings →
   Environment Variables**.
4. Deploy. Tidak perlu VPS — seluruh backend berjalan sebagai serverless
   functions (API routes) + Supabase sebagai database.

Deploy ke Netlify juga didukung (gunakan plugin `@netlify/plugin-nextjs`).

## Keamanan yang sudah diimplementasikan

- Semua input divalidasi server-side dengan `zod` (`lib/validators.js`).
- Harga & jumlah like **selalu** diambil dari database, tidak pernah
  dipercaya dari request client.
- Webhook memverifikasi signature sebelum memproses apa pun, dan mencatat
  setiap event di tabel `webhook_events` dengan unique constraint untuk
  idempotency — webhook yang sama tidak akan memproses order dua kali.
- Fulfillment memakai idempotency key per order (`lib/fulfillment.js`) —
  retry tidak akan mengirim like dua kali.
- Session admin memakai JWT yang ditandatangani (`jose`), cookie
  `httpOnly` + `secure`, tidak ada auth hardcode.
- Rate limiting dasar di endpoint yang rawan abuse (`lib/rateLimit.js`) —
  untuk multi-instance deployment, ganti dengan Redis/Upstash.
- Klaim gratis memakai hash (bukan UID/IP mentah) untuk pengecekan
  anti-abuse, sesuai prinsip minimal data collection.
- Audit log (`audit_logs`) mencatat setiap perubahan status order/produk
  oleh admin maupun webhook.

## Yang belum termasuk / rekomendasi lanjutan

- Rate limiter in-memory perlu diganti ke Redis/Upstash untuk deployment
  multi-instance (Vercel serverless bisa menjalankan banyak instance
  paralel).
- Belum ada notifikasi email/WhatsApp otomatis ke customer — order hanya
  bisa dicek manual lewat Order ID sesuai spesifikasi ("zero customer
  login").
- Untuk multi-admin dengan role berbeda, gunakan tabel `admin_users` yang
  sudah ada di skema (saat ini login masih single-admin lewat env var).
