-- FFLIKE STORE — database schema (PostgreSQL / Supabase)
-- Run this once in the Supabase SQL editor (or via `supabase db push`).

create extension if not exists "pgcrypto";

-- ==========================================================
-- PRODUCTS
-- ==========================================================
create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,               -- e.g. "free-45", "like-100"
  name text not null,                      -- "45 Like Gratis", "100 Like"
  like_amount integer not null check (like_amount > 0),
  price_idr integer not null default 0 check (price_idr >= 0), -- 0 = free product
  is_free boolean not null default false,
  is_active boolean not null default true,
  is_popular boolean not null default false,
  sort_order integer not null default 0,
  processing_time_label text default 'A few minutes',
  description text,
  -- free-product-only config (ignored for paid products)
  free_cooldown_hours integer default 24,
  free_max_claims_per_uid integer default 1,
  free_max_claims_per_period integer default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ==========================================================
-- ORDERS
-- ==========================================================
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  order_id text unique not null,           -- public, e.g. FFL-20260912-8X4K2
  product_id uuid not null references products(id),
  uid text not null,                       -- Free Fire UID (game account id, not a person)
  nickname text not null,
  note text,
  quantity integer not null,               -- like amount snapshot at order time
  amount integer not null default 0,       -- price snapshot (IDR), server-computed
  is_free boolean not null default false,
  payment_status text not null default 'PENDING'
    check (payment_status in ('PENDING','PAID','FAILED','EXPIRED','REFUNDED','NOT_REQUIRED')),
  order_status text not null default 'WAITING_PAYMENT'
    check (order_status in ('WAITING_PAYMENT','PROCESSING','COMPLETED','FAILED','CANCELLED')),
  payment_reference text,                  -- gateway transaction / invoice id
  fulfillment_reference text,
  fulfillment_error text,
  client_ip_hash text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_orders_order_id on orders(order_id);
create index if not exists idx_orders_created_at on orders(created_at desc);
create index if not exists idx_orders_status on orders(order_status, payment_status);

-- ==========================================================
-- PAYMENTS (one row per gateway payment session/attempt)
-- ==========================================================
create table if not exists payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  provider text not null,                  -- midtrans | xendit | tripay | duitku
  provider_reference text not null,        -- gateway's transaction/invoice id
  qr_string text,                          -- raw QRIS payload, if returned directly
  qr_image_url text,
  amount integer not null,
  currency text not null default 'IDR',
  status text not null default 'PENDING'
    check (status in ('PENDING','PAID','FAILED','EXPIRED','REFUNDED')),
  raw_response jsonb,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists idx_payments_provider_ref
  on payments(provider, provider_reference);

-- ==========================================================
-- WEBHOOK EVENTS (idempotency ledger)
-- ==========================================================
create table if not exists webhook_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  event_id text not null,                  -- provider's unique event/notification id
  order_id uuid references orders(id),
  payload jsonb not null,
  signature_valid boolean not null,
  processed boolean not null default false,
  received_at timestamptz not null default now()
);

-- The same event must never be applied twice.
create unique index if not exists idx_webhook_events_unique
  on webhook_events(provider, event_id);

-- ==========================================================
-- FULFILLMENT JOBS
-- ==========================================================
create table if not exists fulfillment_jobs (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  status text not null default 'QUEUED'
    check (status in ('QUEUED','SENT','SUCCESS','FAILED','RETRY')),
  attempts integer not null default 0,
  idempotency_key text not null,
  request_payload jsonb,
  response_payload jsonb,
  error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists idx_fulfillment_idempotency
  on fulfillment_jobs(idempotency_key);

-- ==========================================================
-- FREE CLAIMS (anti-abuse ledger — no unnecessary personal data)
-- ==========================================================
create table if not exists free_claims (
  id uuid primary key default gen_random_uuid(),
  uid_hash text not null,                  -- sha256(UID + pepper), never the raw UID here
  order_id uuid references orders(id),
  ip_hash text,                            -- sha256(IP + pepper), for rate limiting only
  claimed_at timestamptz not null default now(),
  cooldown_until timestamptz not null,
  created_at timestamptz not null default now()
);

create index if not exists idx_free_claims_uid_hash on free_claims(uid_hash);
create index if not exists idx_free_claims_ip_hash on free_claims(ip_hash);
create index if not exists idx_free_claims_claimed_at on free_claims(claimed_at desc);

-- ==========================================================
-- ADMIN USERS
-- ==========================================================
create table if not exists admin_users (
  id uuid primary key default gen_random_uuid(),
  username text unique not null,
  password_hash text not null,
  role text not null default 'admin' check (role in ('admin','superadmin')),
  created_at timestamptz not null default now()
);

-- ==========================================================
-- AUDIT LOGS
-- ==========================================================
create table if not exists audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor text not null,                     -- admin username, or 'system'/'webhook'
  action text not null,                    -- e.g. "order.status_changed"
  target_type text not null,               -- "order" | "product" | "payment"
  target_id text not null,
  before jsonb,
  after jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_audit_logs_target on audit_logs(target_type, target_id);

-- ==========================================================
-- updated_at triggers
-- ==========================================================
create or replace function set_updated_at() returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_products_updated_at on products;
create trigger trg_products_updated_at before update on products
  for each row execute function set_updated_at();

drop trigger if exists trg_orders_updated_at on orders;
create trigger trg_orders_updated_at before update on orders
  for each row execute function set_updated_at();

drop trigger if exists trg_payments_updated_at on payments;
create trigger trg_payments_updated_at before update on payments
  for each row execute function set_updated_at();

drop trigger if exists trg_fulfillment_jobs_updated_at on fulfillment_jobs;
create trigger trg_fulfillment_jobs_updated_at before update on fulfillment_jobs
  for each row execute function set_updated_at();

-- ==========================================================
-- Seed default products (safe to edit/re-run with ON CONFLICT)
-- ==========================================================
insert into products (slug, name, like_amount, price_idr, is_free, is_active, is_popular, sort_order, processing_time_label, description)
values
  ('free-45', '45 Like Gratis', 45, 0, true, true, false, 0, '1-5 menit', 'Coba layanan kami tanpa pembayaran.'),
  ('like-100', '100 Like', 100, 1000, false, true, false, 1, '5-15 menit', null),
  ('like-500', '500 Like', 500, 3000, false, true, true, 2, '10-30 menit', null),
  ('like-1000', '1.000 Like', 1000, 5000, false, true, false, 3, '10-30 menit', null),
  ('like-5000', '5.000 Like', 5000, 15000, false, true, false, 4, '30-60 menit', null),
  ('like-10000', '10.000 Like', 10000, 25000, false, true, false, 5, '30-90 menit', null)
on conflict (slug) do nothing;

-- Row Level Security: only the service role (used server-side) may touch these
-- tables directly. All client access goes through the Next.js API routes.
alter table products enable row level security;
alter table orders enable row level security;
alter table payments enable row level security;
alter table webhook_events enable row level security;
alter table fulfillment_jobs enable row level security;
alter table free_claims enable row level security;
alter table admin_users enable row level security;
alter table audit_logs enable row level security;

-- Public (anon) read-only access to active products only.
drop policy if exists "public read active products" on products;
create policy "public read active products" on products
  for select using (is_active = true);

-- No anon policies are defined for orders/payments/etc: the anon key cannot
-- read or write them. All privileged access uses SUPABASE_SERVICE_ROLE_KEY
-- from server-side code only (see lib/supabaseAdmin.js).
