import { redirect } from "next/navigation";
import Link from "next/link";
import { getAdminSession } from "@/lib/auth";
import AdminLogoutButton from "@/components/AdminLogoutButton";

export default async function AdminLayout({ children }) {
  const session = await getAdminSession();
  if (!session) redirect("/admin/login");

  return (
    <div className="mx-auto flex min-h-screen max-w-6xl gap-6 px-6 py-8">
      <aside className="glass sticky top-8 hidden h-fit w-56 shrink-0 flex-col gap-1 rounded-2xl p-3 md:flex">
        <div className="px-3 py-2">
          <span className="font-display text-sm font-semibold">
            FFLIKE <span className="text-ion-violet">ADMIN</span>
          </span>
        </div>
        <NavItem href="/admin" label="Dashboard" />
        <NavItem href="/admin/orders" label="Pesanan" />
        <NavItem href="/admin/products" label="Produk" />
        <div className="mt-2 px-1">
          <AdminLogoutButton />
        </div>
      </aside>

      <div className="min-w-0 flex-1">
        <div className="mb-4 flex items-center justify-between md:hidden">
          <span className="font-display text-sm font-semibold">
            FFLIKE <span className="text-ion-violet">ADMIN</span>
          </span>
          <AdminLogoutButton compact />
        </div>
        <nav className="glass mb-4 flex gap-1 rounded-2xl p-1.5 md:hidden">
          <NavItem href="/admin" label="Dashboard" />
          <NavItem href="/admin/orders" label="Pesanan" />
          <NavItem href="/admin/products" label="Produk" />
        </nav>
        {children}
      </div>
    </div>
  );
}

function NavItem({ href, label }) {
  return (
    <Link
      href={href}
      className="flex-1 rounded-xl px-3 py-2 text-center text-sm text-ink-muted transition hover:bg-white/[0.06] hover:text-ink md:text-left"
    >
      {label}
    </Link>
  );
}
