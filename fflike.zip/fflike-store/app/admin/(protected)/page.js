"use client";

import { useEffect, useState } from "react";

function formatIdr(amount) {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(
    amount
  );
}

export default function AdminDashboardPage() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch("/api/admin/stats")
      .then((res) => res.json().then((body) => ({ ok: res.ok, body })))
      .then(({ ok, body }) => {
        if (!ok) {
          setError(body.error || "Gagal memuat statistik.");
          return;
        }
        setData(body);
      })
      .catch(() => setError("Tidak bisa terhubung ke server."));
  }, []);

  if (error) {
    return <div className="glass rounded-2xl p-6 text-sm text-red-300">{error}</div>;
  }

  if (!data) {
    return (
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="skeleton h-24 rounded-2xl" />
        ))}
      </div>
    );
  }

  const cards = [
    { label: "Total Orders", value: data.totals.totalOrders },
    { label: "Free Orders", value: data.totals.freeOrders },
    { label: "Paid Orders", value: data.totals.paidOrders },
    { label: "Processing", value: data.totals.processing },
    { label: "Completed", value: data.totals.completed },
    { label: "Failed", value: data.totals.failed },
    { label: "Total Revenue", value: formatIdr(data.totals.totalRevenue), wide: true }
  ];

  const maxOrders = Math.max(1, ...data.series.map((d) => d.orders));
  const maxRevenue = Math.max(1, ...data.series.map((d) => d.revenue));

  return (
    <div className="flex flex-col gap-6">
      <h1 className="font-display text-2xl font-semibold">Dashboard</h1>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className={`glass rounded-2xl p-4 ${c.wide ? "col-span-2" : ""}`}>
            <p className="text-xs text-ink-faint">{c.label}</p>
            <p className="mono-data mt-1 font-display text-xl font-semibold text-gradient-violet md:text-2xl">
              {c.value}
            </p>
          </div>
        ))}
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <div className="glass rounded-2xl p-5">
          <p className="text-sm font-medium">Orders per Day</p>
          <MiniBarChart series={data.series} valueKey="orders" max={maxOrders} tone="violet" />
        </div>
        <div className="glass rounded-2xl p-5">
          <p className="text-sm font-medium">Revenue per Day</p>
          <MiniBarChart series={data.series} valueKey="revenue" max={maxRevenue} tone="cyan" format={formatIdr} />
        </div>
      </div>

      <div className="glass rounded-2xl p-5">
        <p className="text-sm font-medium">Free vs Paid Orders</p>
        <div className="mt-4 flex h-4 overflow-hidden rounded-full bg-white/[0.06]">
          {(() => {
            const total = data.totals.freeOrders + data.totals.paidOrders || 1;
            const freePct = (data.totals.freeOrders / total) * 100;
            return (
              <>
                <div className="bg-ion-cyan" style={{ width: `${freePct}%` }} />
                <div className="bg-ion-violet" style={{ width: `${100 - freePct}%` }} />
              </>
            );
          })()}
        </div>
        <div className="mt-2 flex gap-4 text-xs text-ink-muted">
          <span><span className="mr-1 inline-block h-2 w-2 rounded-full bg-ion-cyan" />Free ({data.totals.freeOrders})</span>
          <span><span className="mr-1 inline-block h-2 w-2 rounded-full bg-ion-violet" />Paid ({data.totals.paidOrders})</span>
        </div>
      </div>
    </div>
  );
}

function MiniBarChart({ series, valueKey, max, tone, format }) {
  if (series.length === 0) {
    return <p className="mt-6 text-xs text-ink-faint">Belum ada data.</p>;
  }
  const barColor = tone === "cyan" ? "bg-ion-cyan" : "bg-ion-violet";

  return (
    <div className="mt-4 flex h-32 items-end gap-1">
      {series.slice(-30).map((d) => (
        <div key={d.day} className="group relative flex-1">
          <div
            className={`${barColor} rounded-t opacity-70 transition group-hover:opacity-100`}
            style={{ height: `${Math.max(4, (d[valueKey] / max) * 100)}%` }}
          />
          <div className="pointer-events-none absolute -top-8 left-1/2 hidden -translate-x-1/2 whitespace-nowrap rounded-md bg-base-raised px-2 py-1 text-[10px] text-ink group-hover:block">
            {d.day}: {format ? format(d[valueKey]) : d[valueKey]}
          </div>
        </div>
      ))}
    </div>
  );
}
