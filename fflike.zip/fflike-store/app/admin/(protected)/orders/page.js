"use client";

import { useEffect, useState, useCallback } from "react";

function formatIdr(amount) {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(
    amount
  );
}

const ORDER_STATUSES = ["WAITING_PAYMENT", "PROCESSING", "COMPLETED", "FAILED", "CANCELLED"];
const PAYMENT_STATUSES = ["PENDING", "PAID", "FAILED", "EXPIRED", "REFUNDED", "NOT_REQUIRED"];

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState(null);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [orderStatus, setOrderStatus] = useState("");
  const [paymentStatus, setPaymentStatus] = useState("");
  const [selected, setSelected] = useState(null);
  const [error, setError] = useState(null);

  const load = useCallback(() => {
    const params = new URLSearchParams({ page: String(page), pageSize: "20" });
    if (search) params.set("search", search);
    if (orderStatus) params.set("orderStatus", orderStatus);
    if (paymentStatus) params.set("paymentStatus", paymentStatus);

    fetch(`/api/admin/orders?${params}`)
      .then((res) => res.json().then((body) => ({ ok: res.ok, body })))
      .then(({ ok, body }) => {
        if (!ok) {
          setError(body.error || "Gagal memuat pesanan.");
          return;
        }
        setOrders(body.orders);
        setTotal(body.pagination.total);
      })
      .catch(() => setError("Tidak bisa terhubung ke server."));
  }, [page, search, orderStatus, paymentStatus]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold">Pesanan</h1>
      </div>

      <div className="glass flex flex-col gap-3 rounded-2xl p-4 md:flex-row md:items-center">
        <input
          value={search}
          onChange={(e) => {
            setPage(1);
            setSearch(e.target.value);
          }}
          placeholder="Cari Order ID, UID, atau nickname..."
          className="flex-1 rounded-xl border border-line bg-white/[0.03] px-4 py-2.5 text-sm outline-none focus:border-ion-violet/60"
        />
        <select
          value={orderStatus}
          onChange={(e) => {
            setPage(1);
            setOrderStatus(e.target.value);
          }}
          className="rounded-xl border border-line bg-base-raised px-3 py-2.5 text-sm"
        >
          <option value="">Semua Status Order</option>
          {ORDER_STATUSES.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
        <select
          value={paymentStatus}
          onChange={(e) => {
            setPage(1);
            setPaymentStatus(e.target.value);
          }}
          className="rounded-xl border border-line bg-base-raised px-3 py-2.5 text-sm"
        >
          <option value="">Semua Status Bayar</option>
          {PAYMENT_STATUSES.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </div>

      {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>}

      <div className="glass overflow-x-auto rounded-2xl">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs uppercase tracking-wide text-ink-faint">
              <th className="px-4 py-3">Order ID</th>
              <th className="px-4 py-3">Produk</th>
              <th className="px-4 py-3">UID / Nickname</th>
              <th className="px-4 py-3">Total</th>
              <th className="px-4 py-3">Bayar</th>
              <th className="px-4 py-3">Order</th>
              <th className="px-4 py-3">Dibuat</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody>
            {orders === null && (
              <tr>
                <td colSpan={8} className="px-4 py-6 text-center text-ink-faint">Memuat...</td>
              </tr>
            )}
            {orders?.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-6 text-center text-ink-faint">Tidak ada pesanan yang cocok.</td>
              </tr>
            )}
            {orders?.map((o) => (
              <tr key={o.id} className="border-b border-line/60 last:border-0 hover:bg-white/[0.02]">
                <td className="mono-data px-4 py-3">{o.orderId}</td>
                <td className="px-4 py-3">{o.product}</td>
                <td className="px-4 py-3">
                  <div className="mono-data">{o.uid}</div>
                  <div className="text-xs text-ink-faint">{o.nickname}</div>
                </td>
                <td className="px-4 py-3">{formatIdr(o.amount)}</td>
                <td className="px-4 py-3"><Badge value={o.paymentStatus} /></td>
                <td className="px-4 py-3"><Badge value={o.orderStatus} /></td>
                <td className="px-4 py-3 text-xs text-ink-faint">{new Date(o.createdAt).toLocaleString("id-ID")}</td>
                <td className="px-4 py-3">
                  <button onClick={() => setSelected(o.id)} className="text-xs font-semibold text-ion-violet hover:underline">
                    Detail
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between text-xs text-ink-faint">
        <span>{total} pesanan ditemukan</span>
        <div className="flex gap-2">
          <button
            disabled={page <= 1}
            onClick={() => setPage((p) => p - 1)}
            className="glass rounded-lg px-3 py-1.5 disabled:opacity-40"
          >
            Sebelumnya
          </button>
          <button
            disabled={page * 20 >= total}
            onClick={() => setPage((p) => p + 1)}
            className="glass rounded-lg px-3 py-1.5 disabled:opacity-40"
          >
            Berikutnya
          </button>
        </div>
      </div>

      {selected && (
        <OrderDetailModal orderId={selected} onClose={() => setSelected(null)} onChanged={load} />
      )}
    </div>
  );
}

function Badge({ value }) {
  const tone = ["PAID", "COMPLETED", "NOT_REQUIRED"].includes(value)
    ? "bg-ion-cyan/15 text-ion-cyan"
    : ["FAILED", "EXPIRED", "CANCELLED"].includes(value)
    ? "bg-red-500/15 text-red-300"
    : "bg-ion-violet/15 text-ion-violet";
  return <span className={`rounded-full px-2 py-1 text-[11px] font-semibold ${tone}`}>{value}</span>;
}

function OrderDetailModal({ orderId, onClose, onChanged }) {
  const [order, setOrder] = useState(null);
  const [webhookEvents, setWebhookEvents] = useState([]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState(null);

  const load = useCallback(() => {
    fetch(`/api/admin/orders/${orderId}`)
      .then((res) => res.json())
      .then((data) => {
        setOrder(data.order);
        setWebhookEvents(data.webhookEvents || []);
      });
  }, [orderId]);

  useEffect(() => {
    load();
  }, [load]);

  async function updateStatus(newStatus) {
    setBusy(true);
    setMessage(null);
    const res = await fetch(`/api/admin/orders/${orderId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ orderStatus: newStatus })
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) {
      setMessage(data.error || "Gagal memperbarui status.");
      return;
    }
    load();
    onChanged();
  }

  async function retryFulfillment() {
    setBusy(true);
    setMessage(null);
    const res = await fetch(`/api/admin/orders/${orderId}/retry`, { method: "POST" });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) {
      setMessage(data.error || "Gagal retry fulfillment.");
      return;
    }
    setMessage("Fulfillment dikirim ulang.");
    load();
    onChanged();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0 md:items-center md:p-6" onClick={onClose}>
      <div
        className="glass-raised max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-t-3xl p-6 md:rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold">Detail Pesanan</h2>
          <button onClick={onClose} className="text-ink-faint">✕</button>
        </div>

        {!order ? (
          <p className="mt-6 text-sm text-ink-faint">Memuat...</p>
        ) : (
          <div className="mt-4 flex flex-col gap-4 text-sm">
            <div className="mono-data text-ion-violet">{order.order_id}</div>
            <Detail label="UID" value={order.uid} />
            <Detail label="Nickname" value={order.nickname} />
            <Detail label="Produk" value={order.products?.name} />
            <Detail label="Jumlah" value={`${order.quantity} like`} />
            <Detail label="Total" value={formatIdr(order.amount)} />
            <Detail label="Status Bayar" value={order.payment_status} />
            <Detail label="Status Order" value={order.order_status} />
            {order.fulfillment_error && (
              <Detail label="Error Fulfillment" value={order.fulfillment_error} danger />
            )}

            <div>
              <p className="mb-1.5 text-xs text-ink-muted">Ubah Status Order</p>
              <div className="flex flex-wrap gap-2">
                {ORDER_STATUSES.map((s) => (
                  <button
                    key={s}
                    disabled={busy || order.order_status === s}
                    onClick={() => updateStatus(s)}
                    className="glass btn-press rounded-lg px-2.5 py-1.5 text-xs disabled:opacity-40"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <button
              disabled={busy}
              onClick={retryFulfillment}
              className="btn-press rounded-xl bg-ion-violet px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
            >
              Retry Fulfillment
            </button>

            {message && <p className="text-xs text-ion-cyan">{message}</p>}

            <div>
              <p className="mb-1.5 text-xs text-ink-muted">Riwayat Webhook</p>
              {webhookEvents.length === 0 ? (
                <p className="text-xs text-ink-faint">Belum ada webhook untuk pesanan ini.</p>
              ) : (
                <ul className="flex flex-col gap-1.5">
                  {webhookEvents.map((w) => (
                    <li key={w.id} className="glass rounded-lg px-3 py-2 text-xs">
                      <span className={w.signature_valid ? "text-ion-cyan" : "text-red-300"}>
                        {w.signature_valid ? "Valid" : "Invalid"}
                      </span>{" "}
                      · {new Date(w.received_at).toLocaleString("id-ID")}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Detail({ label, value, danger }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className="text-ink-muted">{label}</span>
      <span className={danger ? "text-right text-red-300" : "text-right"}>{value}</span>
    </div>
  );
}
