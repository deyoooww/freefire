"use client";

import { useEffect, useState, useCallback } from "react";

function formatIdr(amount) {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(
    amount
  );
}

const emptyForm = {
  slug: "",
  name: "",
  likeAmount: "",
  priceIdr: "",
  isFree: false,
  isActive: true,
  isPopular: false,
  sortOrder: "0",
  processingTimeLabel: "",
  description: "",
  freeCooldownHours: "24",
  freeMaxClaimsPerUid: "1",
  freeMaxClaimsPerPeriod: "1"
};

export default function AdminProductsPage() {
  const [products, setProducts] = useState(null);
  const [error, setError] = useState(null);
  const [editing, setEditing] = useState(null); // product being edited, or 'new'
  const [form, setForm] = useState(emptyForm);
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState(null);

  const load = useCallback(() => {
    fetch("/api/admin/products")
      .then((res) => res.json().then((body) => ({ ok: res.ok, body })))
      .then(({ ok, body }) => {
        if (!ok) {
          setError(body.error || "Gagal memuat produk.");
          return;
        }
        setProducts(body.products);
      })
      .catch(() => setError("Tidak bisa terhubung ke server."));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function openNew() {
    setForm(emptyForm);
    setFormError(null);
    setEditing("new");
  }

  function openEdit(p) {
    setForm({
      slug: p.slug,
      name: p.name,
      likeAmount: String(p.like_amount),
      priceIdr: String(p.price_idr),
      isFree: p.is_free,
      isActive: p.is_active,
      isPopular: p.is_popular,
      sortOrder: String(p.sort_order),
      processingTimeLabel: p.processing_time_label || "",
      description: p.description || "",
      freeCooldownHours: String(p.free_cooldown_hours ?? 24),
      freeMaxClaimsPerUid: String(p.free_max_claims_per_uid ?? 1),
      freeMaxClaimsPerPeriod: String(p.free_max_claims_per_period ?? 1)
    });
    setFormError(null);
    setEditing(p.id);
  }

  async function handleSave() {
    setBusy(true);
    setFormError(null);

    const isNew = editing === "new";
    const payload = {
      name: form.name,
      likeAmount: Number(form.likeAmount),
      priceIdr: Number(form.priceIdr || 0),
      isActive: form.isActive,
      isPopular: form.isPopular,
      sortOrder: Number(form.sortOrder || 0),
      processingTimeLabel: form.processingTimeLabel || undefined,
      description: form.description || undefined,
      freeCooldownHours: form.isFree ? Number(form.freeCooldownHours || 24) : undefined,
      freeMaxClaimsPerUid: form.isFree ? Number(form.freeMaxClaimsPerUid || 1) : undefined,
      freeMaxClaimsPerPeriod: form.isFree ? Number(form.freeMaxClaimsPerPeriod || 1) : undefined
    };
    if (isNew) {
      payload.slug = form.slug;
      payload.isFree = form.isFree;
    }

    const res = await fetch(isNew ? "/api/admin/products" : `/api/admin/products/${editing}`, {
      method: isNew ? "POST" : "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    setBusy(false);

    if (!res.ok) {
      setFormError(data.error || "Gagal menyimpan produk.");
      return;
    }

    setEditing(null);
    load();
  }

  async function handleDeactivate(id) {
    if (!confirm("Nonaktifkan produk ini?")) return;
    await fetch(`/api/admin/products/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold">Produk</h1>
        <button
          onClick={openNew}
          className="btn-press rounded-xl bg-ion-violet px-4 py-2 text-sm font-semibold text-white"
        >
          + Produk Baru
        </button>
      </div>

      {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>}

      <div className="glass overflow-x-auto rounded-2xl">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs uppercase tracking-wide text-ink-faint">
              <th className="px-4 py-3">Nama</th>
              <th className="px-4 py-3">Like</th>
              <th className="px-4 py-3">Harga</th>
              <th className="px-4 py-3">Urutan</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody>
            {products === null && (
              <tr><td colSpan={6} className="px-4 py-6 text-center text-ink-faint">Memuat...</td></tr>
            )}
            {products?.map((p) => (
              <tr key={p.id} className="border-b border-line/60 last:border-0">
                <td className="px-4 py-3">
                  {p.name}
                  {p.is_free && <span className="ml-2 rounded-full bg-ion-cyan/15 px-2 py-0.5 text-[10px] text-ion-cyan">FREE</span>}
                  {p.is_popular && <span className="ml-2 rounded-full bg-ion-violet/15 px-2 py-0.5 text-[10px] text-ion-violet">POPULER</span>}
                </td>
                <td className="px-4 py-3">{p.like_amount.toLocaleString("id-ID")}</td>
                <td className="px-4 py-3">{formatIdr(p.price_idr)}</td>
                <td className="px-4 py-3">{p.sort_order}</td>
                <td className="px-4 py-3">
                  <span className={p.is_active ? "text-ion-cyan" : "text-ink-faint"}>
                    {p.is_active ? "Aktif" : "Nonaktif"}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <button onClick={() => openEdit(p)} className="mr-3 text-xs font-semibold text-ion-violet hover:underline">
                    Edit
                  </button>
                  {p.is_active && (
                    <button onClick={() => handleDeactivate(p.id)} className="text-xs font-semibold text-red-300 hover:underline">
                      Nonaktifkan
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editing && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0 md:items-center md:p-6" onClick={() => setEditing(null)}>
          <div
            className="glass-raised max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-t-3xl p-6 md:rounded-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 className="font-display text-lg font-semibold">
              {editing === "new" ? "Produk Baru" : "Edit Produk"}
            </h2>

            <div className="mt-4 flex flex-col gap-3">
              {editing === "new" && (
                <TextField label="Slug (unik, huruf kecil + strip)" value={form.slug} onChange={(v) => setForm({ ...form, slug: v })} placeholder="like-2000" />
              )}
              <TextField label="Nama Produk" value={form.name} onChange={(v) => setForm({ ...form, name: v })} />
              <div className="grid grid-cols-2 gap-3">
                <TextField label="Jumlah Like" value={form.likeAmount} onChange={(v) => setForm({ ...form, likeAmount: v })} type="number" />
                <TextField label="Harga (Rp)" value={form.priceIdr} onChange={(v) => setForm({ ...form, priceIdr: v })} type="number" disabled={form.isFree} />
              </div>
              <TextField label="Estimasi Proses" value={form.processingTimeLabel} onChange={(v) => setForm({ ...form, processingTimeLabel: v })} placeholder="10-30 menit" />
              <TextField label="Deskripsi (opsional)" value={form.description} onChange={(v) => setForm({ ...form, description: v })} />
              <TextField label="Urutan Tampil" value={form.sortOrder} onChange={(v) => setForm({ ...form, sortOrder: v })} type="number" />

              <div className="flex flex-wrap gap-4">
                {editing === "new" && (
                  <CheckField label="Produk gratis" checked={form.isFree} onChange={(v) => setForm({ ...form, isFree: v })} />
                )}
                <CheckField label="Aktif" checked={form.isActive} onChange={(v) => setForm({ ...form, isActive: v })} />
                <CheckField label="Populer" checked={form.isPopular} onChange={(v) => setForm({ ...form, isPopular: v })} />
              </div>

              {form.isFree && (
                <div className="glass rounded-xl p-3">
                  <p className="mb-2 text-xs text-ink-muted">Pengaturan Anti-Abuse</p>
                  <div className="grid grid-cols-3 gap-2">
                    <TextField label="Cooldown (jam)" value={form.freeCooldownHours} onChange={(v) => setForm({ ...form, freeCooldownHours: v })} type="number" />
                    <TextField label="Maks/UID" value={form.freeMaxClaimsPerUid} onChange={(v) => setForm({ ...form, freeMaxClaimsPerUid: v })} type="number" />
                    <TextField label="Maks/Periode" value={form.freeMaxClaimsPerPeriod} onChange={(v) => setForm({ ...form, freeMaxClaimsPerPeriod: v })} type="number" />
                  </div>
                </div>
              )}

              {formError && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs text-red-300">{formError}</p>}

              <div className="mt-2 flex gap-3">
                <button onClick={() => setEditing(null)} className="glass flex-1 rounded-xl px-4 py-2.5 text-sm">
                  Batal
                </button>
                <button
                  onClick={handleSave}
                  disabled={busy}
                  className="btn-press flex-1 rounded-xl bg-ion-violet px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
                >
                  {busy ? "Menyimpan..." : "Simpan"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function TextField({ label, value, onChange, type = "text", placeholder, disabled }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-ink-muted">{label}</span>
      <input
        type={type}
        value={value}
        disabled={disabled}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-line bg-white/[0.03] px-3 py-2 text-sm outline-none focus:border-ion-violet/60 disabled:opacity-40"
      />
    </label>
  );
}

function CheckField({ label, checked, onChange }) {
  return (
    <label className="flex items-center gap-2 text-sm text-ink-muted">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="h-4 w-4 accent-ion-violet" />
      {label}
    </label>
  );
}
