import Navbar from "@/components/Navbar";
import BottomNav from "@/components/BottomNav";
import Footer from "@/components/Footer";
import Hero from "@/components/Hero";
import FreeClaimCard from "@/components/FreeClaimCard";
import PackageGrid from "@/components/PackageGrid";
import HowItWorks from "@/components/HowItWorks";
import OrderTrackerWidget from "@/components/OrderTrackerWidget";
import Faq from "@/components/Faq";

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main className="pb-24 md:pb-0">
        <Hero />
        <FreeClaimCard />
        <PackageGrid />
        <HowItWorks />
        <OrderTrackerWidget />
        <Faq />
        <CtaBanner />
      </main>
      <Footer />
      <BottomNav />
    </>
  );
}

function CtaBanner() {
  return (
    <section className="mx-auto max-w-6xl px-6 pt-20">
      <div className="glass glass-glow-violet flex flex-col items-center gap-4 rounded-3xl px-6 py-10 text-center">
        <h2 className="font-display text-2xl font-semibold md:text-3xl">
          Siap boost profil Free Fire kamu?
        </h2>
        <p className="max-w-md text-sm text-ink-muted">
          Mulai dari 45 like gratis, tanpa akun, tanpa ribet.
        </p>
        <a
          href="#free-claim"
          className="btn-press mt-2 rounded-xl bg-gradient-to-b from-ion-cyan to-[#17B79A] px-7 py-3.5 text-sm font-semibold text-[#03211B]"
        >
          Klaim 45 Like Gratis
        </a>
      </div>
    </section>
  );
}
