"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import BottomNav from "@/components/BottomNav";

export default function OrderSearchPage() {
  const router = useRouter();
  const [orderId, setOrderId] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    const trimmed = orderId.trim().toUpperCase();
    if (!trimmed) return;
    router.push(`/order/${trimmed}`);
  }

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-md px-6 pb-28 pt-16 md:pb-16">
        <h1 className="font-display text-2xl font-semibold md:text-3xl">Lacak Pesanan</h1>
        <p className="mt-1 text-sm text-ink-muted">Masukkan Order ID yang kamu terima setelah membuat pesanan.</p>

        <form onSubmit={handleSubmit} className="glass mt-6 flex flex-col gap-3 rounded-2xl p-5">
          <input
            value={orderId}
            onChange={(e) => setOrderId(e.target.value)}
            placeholder="FFL-20260912-8X4K2"
            className="mono-data w-full rounded-xl border border-line bg-white/[0.03] px-4 py-3 text-sm outline-none placeholder:text-ink-faint focus:border-ion-violet/60"
          />
          <button className="btn-press rounded-xl bg-ion-violet px-4 py-3 text-sm font-semibold text-white transition hover:brightness-110">
            Cek Status
          </button>
        </form>
      </main>
      <BottomNav />
    </>
  );
}
