import Navbar from "@/components/Navbar";
import BottomNav from "@/components/BottomNav";
import OrderStatusView from "@/components/OrderStatusView";

export default function OrderDetailPage({ params }) {
  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-xl px-6 pb-28 pt-10 md:pb-16 md:pt-16">
        <OrderStatusView orderId={params.orderId} />
      </main>
      <BottomNav />
    </>
  );
}
