export default function Loading() {
  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <div className="skeleton h-10 w-64 rounded-xl" />
      <div className="skeleton mt-4 h-40 w-full rounded-2xl" />
    </div>
  );
}
