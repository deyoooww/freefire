"use client";

export default function GlobalError({ reset }) {
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-md flex-col items-center justify-center px-6 text-center">
      <h1 className="font-display text-xl font-semibold">Terjadi Kesalahan</h1>
      <p className="mt-2 text-sm text-ink-muted">
        Maaf, terjadi kesalahan yang tidak terduga. Silakan coba lagi.
      </p>
      <button
        onClick={reset}
        className="btn-press mt-5 rounded-xl bg-ion-violet px-5 py-2.5 text-sm font-semibold text-white"
      >
        Coba Lagi
      </button>
    </div>
  );
}
