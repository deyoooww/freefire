import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { generateOrderId, hashForAbuseCheck } from "@/lib/orderId";
import { freeClaimSchema } from "@/lib/validators";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";
import { sendToFulfillment } from "@/lib/fulfillment";

export async function POST(request) {
  const ip = getClientIp(request);
  const ipHash = hashForAbuseCheck(ip);

  // First line of defense: coarse IP rate limit, independent of the DB.
  const rl = checkRateLimit(`free-claim:${ip}`, 5, 60 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: "Terlalu banyak percobaan klaim dari jaringan ini. Coba lagi nanti." },
      { status: 429 }
    );
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Body request tidak valid." }, { status: 400 });
  }

  const parsed = freeClaimSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message || "Input tidak valid." },
      { status: 400 }
    );
  }

  const { uid, nickname } = parsed.data;
  const uidHash = hashForAbuseCheck(uid);

  const { data: product, error: productError } = await supabaseAdmin
    .from("products")
    .select("*")
    .eq("slug", "free-45")
    .eq("is_free", true)
    .maybeSingle();

  if (productError || !product) {
    return NextResponse.json({ error: "Paket gratis tidak ditemukan." }, { status: 404 });
  }

  if (!product.is_active) {
    return NextResponse.json(
      { error: "Klaim gratis sedang tidak aktif. Silakan cek kembali nanti." },
      { status: 403 }
    );
  }

  const cooldownHours = product.free_cooldown_hours ?? 24;
  const maxClaimsPerUid = product.free_max_claims_per_uid ?? 1;
  const maxClaimsPerPeriod = product.free_max_claims_per_period ?? 1;
  const periodStart = new Date(Date.now() - cooldownHours * 60 * 60 * 1000).toISOString();

  // Anti-abuse check #1: this UID must not be inside its own cooldown window.
  const { data: recentByUid, error: uidCheckError } = await supabaseAdmin
    .from("free_claims")
    .select("id, cooldown_until")
    .eq("uid_hash", uidHash)
    .gt("cooldown_until", new Date().toISOString())
    .order("claimed_at", { ascending: false })
    .limit(1);

  if (uidCheckError) {
    console.error("[POST /api/free/claim] uid check", uidCheckError);
    return NextResponse.json({ error: "Terjadi kesalahan pada server." }, { status: 500 });
  }

  if (recentByUid && recentByUid.length > 0) {
    return NextResponse.json(
      {
        error: `UID ini sudah pernah klaim baru-baru ini. Coba lagi setelah ${new Date(
          recentByUid[0].cooldown_until
        ).toLocaleString("id-ID")}.`
      },
      { status: 429 }
    );
  }

  // Anti-abuse check #2: how many times has this UID EVER claimed?
  const { count: uidTotalClaims, error: uidCountError } = await supabaseAdmin
    .from("free_claims")
    .select("id", { count: "exact", head: true })
    .eq("uid_hash", uidHash);

  if (uidCountError) {
    console.error("[POST /api/free/claim] uid count", uidCountError);
    return NextResponse.json({ error: "Terjadi kesalahan pada server." }, { status: 500 });
  }

  if ((uidTotalClaims || 0) >= maxClaimsPerUid && maxClaimsPerUid > 0) {
    return NextResponse.json(
      { error: "UID ini sudah mencapai batas maksimal klaim gratis." },
      { status: 429 }
    );
  }

  // Anti-abuse check #3: how many claims from this IP within the period?
  const { count: ipClaimsInPeriod, error: ipCountError } = await supabaseAdmin
    .from("free_claims")
    .select("id", { count: "exact", head: true })
    .eq("ip_hash", ipHash)
    .gte("claimed_at", periodStart);

  if (ipCountError) {
    console.error("[POST /api/free/claim] ip count", ipCountError);
    return NextResponse.json({ error: "Terjadi kesalahan pada server." }, { status: 500 });
  }

  if ((ipClaimsInPeriod || 0) >= maxClaimsPerPeriod) {
    return NextResponse.json(
      { error: "Batas klaim gratis untuk jaringan ini sudah tercapai. Coba lagi nanti." },
      { status: 429 }
    );
  }

  // All checks passed — create the order (server-generated id, no payment).
  let attempt = 0;
  let order = null;

  while (attempt < 3 && !order) {
    const orderId = generateOrderId();
    const { data, error } = await supabaseAdmin
      .from("orders")
      .insert({
        order_id: orderId,
        product_id: product.id,
        uid,
        nickname,
        quantity: product.like_amount,
        amount: 0,
        is_free: true,
        payment_status: "NOT_REQUIRED",
        order_status: "PROCESSING",
        client_ip_hash: ipHash
      })
      .select()
      .single();

    if (!error) order = data;
    else if (error.code === "23505") attempt += 1;
    else {
      console.error("[POST /api/free/claim] insert order", error);
      return NextResponse.json({ error: "Gagal membuat pesanan gratis." }, { status: 500 });
    }
  }

  if (!order) {
    return NextResponse.json({ error: "Gagal membuat pesanan gratis." }, { status: 500 });
  }

  // Record the claim (hashed identifiers only — no raw UID/IP kept here).
  const cooldownUntil = new Date(Date.now() + cooldownHours * 60 * 60 * 1000).toISOString();
  await supabaseAdmin.from("free_claims").insert({
    uid_hash: uidHash,
    ip_hash: ipHash,
    order_id: order.id,
    cooldown_until: cooldownUntil
  });

  // Free orders skip payment entirely and go straight to fulfillment.
  await sendToFulfillment(order);

  const { data: finalOrder } = await supabaseAdmin
    .from("orders")
    .select("order_status, fulfillment_error")
    .eq("id", order.id)
    .single();

  return NextResponse.json({
    order: {
      orderId: order.order_id,
      product: product.name,
      likeAmount: order.quantity,
      uid: order.uid,
      nickname: order.nickname,
      amount: 0,
      paymentStatus: "NOT_REQUIRED",
      orderStatus: finalOrder?.order_status || order.order_status,
      isFree: true
    },
    warning: finalOrder?.fulfillment_error
      ? "Pesanan dibuat, namun sistem pengiriman like belum terhubung sepenuhnya. Cek status di halaman lacak pesanan."
      : undefined
  });
}
