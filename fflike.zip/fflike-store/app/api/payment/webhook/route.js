import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { getPaymentProvider } from "@/lib/payment";
import { sendToFulfillment } from "@/lib/fulfillment";
import { writeAuditLog } from "@/lib/auditLog";

// Payment gateways POST here directly — this route intentionally does not
// use the app's usual per-IP rate limiter, since legitimate traffic comes
// from the provider's fixed IP range, not end users.
export async function POST(request) {
  const rawBody = await request.text();

  let provider;
  try {
    provider = getPaymentProvider();
  } catch (err) {
    console.error("[webhook] provider not configured", err);
    // Still 200 so the gateway doesn't hammer retries for a config issue
    // that only the store owner can fix, but log loudly server-side.
    return NextResponse.json({ received: true, note: "provider not configured" }, { status: 200 });
  }

  // 1. Verify the signature BEFORE trusting anything in the payload.
  const signatureValid = provider.verifyWebhookSignature(rawBody, request.headers);

  let payload;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  if (!signatureValid) {
    // Still log the attempt for forensics, but never act on it.
    await supabaseAdmin.from("webhook_events").insert({
      provider: process.env.PAYMENT_PROVIDER,
      event_id: `invalid:${Date.now()}:${Math.random().toString(36).slice(2)}`,
      payload,
      signature_valid: false,
      processed: false
    });
    return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  }

  const event = provider.parseWebhookEvent(payload);

  // 2. Idempotency: has this exact event already been recorded?
  const { data: existingEvent } = await supabaseAdmin
    .from("webhook_events")
    .select("id, processed")
    .eq("provider", process.env.PAYMENT_PROVIDER)
    .eq("event_id", event.eventId)
    .maybeSingle();

  if (existingEvent?.processed) {
    // Already handled — acknowledge without doing anything again.
    return NextResponse.json({ received: true, duplicate: true });
  }

  // 3. Find the order this event refers to.
  const { data: payment } = await supabaseAdmin
    .from("payments")
    .select("*, orders(*)")
    .eq("provider", process.env.PAYMENT_PROVIDER)
    .eq("provider_reference", event.providerReference)
    .maybeSingle();

  if (!payment || !payment.orders) {
    await supabaseAdmin.from("webhook_events").insert({
      provider: process.env.PAYMENT_PROVIDER,
      event_id: event.eventId,
      payload,
      signature_valid: true,
      processed: false
    });
    // 200 so the gateway stops retrying something we can't match; it is
    // logged above for manual investigation.
    return NextResponse.json({ received: true, matched: false });
  }

  const order = payment.orders;

  // 4. Amount and currency must match exactly what we charged.
  const amountMatches = event.amount === payment.amount;
  const currencyMatches = event.currency === payment.currency;

  if (!amountMatches || !currencyMatches) {
    await supabaseAdmin.from("webhook_events").insert({
      provider: process.env.PAYMENT_PROVIDER,
      event_id: event.eventId,
      order_id: order.id,
      payload,
      signature_valid: true,
      processed: false
    });
    await writeAuditLog({
      actor: "webhook",
      action: "payment.amount_mismatch",
      targetType: "order",
      targetId: order.order_id,
      before: { expected: payment.amount, currency: payment.currency },
      after: { received: event.amount, currency: event.currency }
    });
    return NextResponse.json({ received: true, mismatch: true }, { status: 200 });
  }

  // 5. Record the event as processed up front (idempotency guard) inside
  // the same logical step as applying the status change.
  const { error: eventInsertError } = await supabaseAdmin.from("webhook_events").insert({
    provider: process.env.PAYMENT_PROVIDER,
    event_id: event.eventId,
    order_id: order.id,
    payload,
    signature_valid: true,
    processed: true
  });

  if (eventInsertError) {
    // Unique constraint hit = a concurrent request already inserted this
    // exact event — treat as duplicate and stop here.
    if (eventInsertError.code === "23505") {
      return NextResponse.json({ received: true, duplicate: true });
    }
    console.error("[webhook] event insert failed", eventInsertError);
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }

  await supabaseAdmin.from("payments").update({ status: event.status }).eq("id", payment.id);

  if (event.status === "PAID") {
    await supabaseAdmin
      .from("orders")
      .update({ payment_status: "PAID", order_status: "PROCESSING" })
      .eq("id", order.id);

    await writeAuditLog({
      actor: "webhook",
      action: "payment.paid",
      targetType: "order",
      targetId: order.order_id,
      before: { paymentStatus: order.payment_status, orderStatus: order.order_status },
      after: { paymentStatus: "PAID", orderStatus: "PROCESSING" }
    });

    const { data: freshOrder } = await supabaseAdmin
      .from("orders")
      .select("*")
      .eq("id", order.id)
      .single();

    await sendToFulfillment(freshOrder);
  } else {
    const orderStatus = event.status === "FAILED" || event.status === "EXPIRED" ? "FAILED" : order.order_status;

    await supabaseAdmin
      .from("orders")
      .update({ payment_status: event.status, order_status: orderStatus })
      .eq("id", order.id);

    await writeAuditLog({
      actor: "webhook",
      action: `payment.${event.status.toLowerCase()}`,
      targetType: "order",
      targetId: order.order_id,
      before: { paymentStatus: order.payment_status },
      after: { paymentStatus: event.status }
    });
  }

  return NextResponse.json({ received: true });
}
