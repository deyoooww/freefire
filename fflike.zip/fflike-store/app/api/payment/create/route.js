import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { getPaymentProvider, PaymentProviderNotConfiguredError } from "@/lib/payment";
import { orderIdParamSchema } from "@/lib/validators";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";

export async function POST(request) {
  const ip = getClientIp(request);
  const rl = checkRateLimit(`payment-create:${ip}`, 10, 10 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json({ error: "Terlalu banyak permintaan." }, { status: 429 });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Body request tidak valid." }, { status: 400 });
  }

  const parsed = orderIdParamSchema.safeParse(body?.orderId);
  if (!parsed.success) {
    return NextResponse.json({ error: "Order ID tidak valid." }, { status: 400 });
  }

  const { data: order, error } = await supabaseAdmin
    .from("orders")
    .select("*")
    .eq("order_id", parsed.data)
    .maybeSingle();

  if (error || !order) {
    return NextResponse.json({ error: "Order tidak ditemukan." }, { status: 404 });
  }

  if (order.is_free) {
    return NextResponse.json(
      { error: "Order gratis tidak memerlukan pembayaran." },
      { status: 400 }
    );
  }

  if (order.payment_status === "PAID") {
    return NextResponse.json({ error: "Order ini sudah dibayar." }, { status: 400 });
  }

  // Reuse an existing, still-valid payment session instead of creating a
  // duplicate one every time the checkout page is opened.
  const { data: existingPayment } = await supabaseAdmin
    .from("payments")
    .select("*")
    .eq("order_id", order.id)
    .eq("status", "PENDING")
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (existingPayment && new Date(existingPayment.expires_at) > new Date()) {
    return NextResponse.json({ payment: toPublicPayment(existingPayment) });
  }

  let provider;
  try {
    provider = getPaymentProvider();
  } catch (err) {
    if (err instanceof PaymentProviderNotConfiguredError) {
      return NextResponse.json(
        {
          error:
            "Gateway pembayaran belum dikonfigurasi di server ini. Hubungi admin untuk mengaktifkan QRIS."
        },
        { status: 503 }
      );
    }
    throw err;
  }

  let result;
  try {
    result = await provider.createQrisPayment({
      orderId: order.order_id,
      amount: order.amount
    });
  } catch (err) {
    console.error("[POST /api/payment/create] provider error", err);
    return NextResponse.json(
      { error: "Gagal membuat sesi pembayaran QRIS. Coba lagi sebentar lagi." },
      { status: 502 }
    );
  }

  const { data: payment, error: insertError } = await supabaseAdmin
    .from("payments")
    .insert({
      order_id: order.id,
      provider: process.env.PAYMENT_PROVIDER,
      provider_reference: result.providerReference,
      qr_string: result.qrString || null,
      qr_image_url: result.qrImageUrl || null,
      amount: order.amount,
      currency: "IDR",
      status: "PENDING",
      raw_response: result.rawResponse,
      expires_at: result.expiresAt
    })
    .select()
    .single();

  if (insertError) {
    console.error("[POST /api/payment/create] insert", insertError);
    return NextResponse.json({ error: "Gagal menyimpan sesi pembayaran." }, { status: 500 });
  }

  return NextResponse.json({ payment: toPublicPayment(payment) });
}

function toPublicPayment(payment) {
  return {
    qrString: payment.qr_string,
    qrImageUrl: payment.qr_image_url,
    amount: payment.amount,
    expiresAt: payment.expires_at,
    status: payment.status
  };
}
