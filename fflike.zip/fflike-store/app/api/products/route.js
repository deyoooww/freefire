import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

export const dynamic = "force-dynamic";

export async function GET() {
  const { data, error } = await supabaseAdmin
    .from("products")
    .select(
      "id, slug, name, like_amount, price_idr, is_free, is_popular, sort_order, processing_time_label, description"
    )
    .eq("is_active", true)
    .order("sort_order", { ascending: true });

  if (error) {
    console.error("[GET /api/products]", error);
    return NextResponse.json(
      { error: "Gagal memuat daftar produk. Coba lagi sebentar lagi." },
      { status: 500 }
    );
  }

  return NextResponse.json({ products: data });
}
