import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { createAdminSession } from "@/lib/auth";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";
import { z } from "zod";

const loginSchema = z.object({
  username: z.string().trim().min(1),
  password: z.string().min(1)
});

export async function POST(request) {
  const ip = getClientIp(request);
  const rl = checkRateLimit(`admin-login:${ip}`, 8, 15 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json({ error: "Terlalu banyak percobaan login." }, { status: 429 });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Body tidak valid." }, { status: 400 });
  }

  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Username dan password wajib diisi." }, { status: 400 });
  }

  const { username, password } = parsed.data;

  // Single-admin bootstrap via env vars, per spec ("jangan hardcode
  // username/password"). For multiple admins, look the user up in the
  // `admin_users` table instead — this comment marks that extension point.
  const expectedUsername = process.env.ADMIN_USERNAME;
  const expectedHash = process.env.ADMIN_PASSWORD_HASH;

  if (!expectedUsername || !expectedHash) {
    return NextResponse.json(
      { error: "Admin belum dikonfigurasi di server. Set ADMIN_USERNAME dan ADMIN_PASSWORD_HASH." },
      { status: 503 }
    );
  }

  const usernameMatches = username === expectedUsername;
  const passwordMatches = usernameMatches ? await bcrypt.compare(password, expectedHash) : false;

  if (!usernameMatches || !passwordMatches) {
    return NextResponse.json({ error: "Username atau password salah." }, { status: 401 });
  }

  await createAdminSession(username, "admin");

  return NextResponse.json({ success: true });
}
