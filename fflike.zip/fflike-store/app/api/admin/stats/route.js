import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { requireAdmin } from "@/lib/auth";

export async function GET() {
  const { unauthorized } = await requireAdmin();
  if (unauthorized) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const [{ count: totalOrders }, { count: freeOrders }, { count: paidOrders }, { count: processing }, { count: completed }, { count: failed }, revenueResult, recentOrders] =
    await Promise.all([
      supabaseAdmin.from("orders").select("id", { count: "exact", head: true }),
      supabaseAdmin.from("orders").select("id", { count: "exact", head: true }).eq("is_free", true),
      supabaseAdmin.from("orders").select("id", { count: "exact", head: true }).eq("is_free", false),
      supabaseAdmin.from("orders").select("id", { count: "exact", head: true }).eq("order_status", "PROCESSING"),
      supabaseAdmin.from("orders").select("id", { count: "exact", head: true }).eq("order_status", "COMPLETED"),
      supabaseAdmin.from("orders").select("id", { count: "exact", head: true }).eq("order_status", "FAILED"),
      supabaseAdmin.from("orders").select("amount").eq("payment_status", "PAID"),
      supabaseAdmin
        .from("orders")
        .select("order_id, created_at, amount, is_free, order_status")
        .order("created_at", { ascending: false })
        .limit(90)
    ]);

  const totalRevenue = (revenueResult.data || []).reduce((sum, o) => sum + o.amount, 0);

  const byDay = new Map();
  for (const o of recentOrders.data || []) {
    const day = o.created_at.slice(0, 10);
    const bucket = byDay.get(day) || { day, orders: 0, revenue: 0, free: 0, paid: 0 };
    bucket.orders += 1;
    bucket.revenue += o.is_free ? 0 : o.amount;
    if (o.is_free) bucket.free += 1;
    else bucket.paid += 1;
    byDay.set(day, bucket);
  }

  return NextResponse.json({
    totals: {
      totalOrders: totalOrders || 0,
      freeOrders: freeOrders || 0,
      paidOrders: paidOrders || 0,
      processing: processing || 0,
      completed: completed || 0,
      failed: failed || 0,
      totalRevenue
    },
    series: Array.from(byDay.values()).sort((a, b) => a.day.localeCompare(b.day))
  });
}
