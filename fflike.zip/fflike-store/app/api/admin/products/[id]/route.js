import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { requireAdmin } from "@/lib/auth";
import { writeAuditLog } from "@/lib/auditLog";
import { z } from "zod";

const patchSchema = z.object({
  name: z.string().trim().min(2).max(60).optional(),
  likeAmount: z.number().int().positive().optional(),
  priceIdr: z.number().int().min(0).optional(),
  isActive: z.boolean().optional(),
  isPopular: z.boolean().optional(),
  sortOrder: z.number().int().optional(),
  processingTimeLabel: z.string().max(60).optional(),
  description: z.string().max(300).optional(),
  freeCooldownHours: z.number().int().positive().optional(),
  freeMaxClaimsPerUid: z.number().int().min(0).optional(),
  freeMaxClaimsPerPeriod: z.number().int().min(0).optional()
});

const fieldMap = {
  name: "name",
  likeAmount: "like_amount",
  priceIdr: "price_idr",
  isActive: "is_active",
  isPopular: "is_popular",
  sortOrder: "sort_order",
  processingTimeLabel: "processing_time_label",
  description: "description",
  freeCooldownHours: "free_cooldown_hours",
  freeMaxClaimsPerUid: "free_max_claims_per_uid",
  freeMaxClaimsPerPeriod: "free_max_claims_per_period"
};

export async function PATCH(request, { params }) {
  const { session, unauthorized } = await requireAdmin();
  if (unauthorized) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Body tidak valid." }, { status: 400 });
  }

  const parsed = patchSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message || "Input tidak valid." },
      { status: 400 }
    );
  }

  const { data: before } = await supabaseAdmin
    .from("products")
    .select("*")
    .eq("id", params.id)
    .maybeSingle();

  if (!before) return NextResponse.json({ error: "Produk tidak ditemukan." }, { status: 404 });

  const update = {};
  for (const [key, value] of Object.entries(parsed.data)) {
    update[fieldMap[key]] = value;
  }

  // Paid products must always carry a non-zero price; free products stay at 0.
  if (before.is_free) update.price_idr = 0;

  const { data: after, error } = await supabaseAdmin
    .from("products")
    .update(update)
    .eq("id", params.id)
    .select()
    .single();

  if (error) return NextResponse.json({ error: "Gagal memperbarui produk." }, { status: 500 });

  await writeAuditLog({
    actor: session.username,
    action: "product.updated",
    targetType: "product",
    targetId: after.id,
    before,
    after
  });

  return NextResponse.json({ product: after });
}

export async function DELETE(_request, { params }) {
  const { session, unauthorized } = await requireAdmin();
  if (unauthorized) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data: before } = await supabaseAdmin
    .from("products")
    .select("*")
    .eq("id", params.id)
    .maybeSingle();

  if (!before) return NextResponse.json({ error: "Produk tidak ditemukan." }, { status: 404 });

  // Soft-delete: keep history intact for existing orders that reference
  // this product. Deactivating is usually what "delete" should mean here.
  const { error } = await supabaseAdmin
    .from("products")
    .update({ is_active: false })
    .eq("id", params.id);

  if (error) return NextResponse.json({ error: "Gagal menghapus produk." }, { status: 500 });

  await writeAuditLog({
    actor: session.username,
    action: "product.deactivated",
    targetType: "product",
    targetId: before.id,
    before,
    after: { is_active: false }
  });

  return NextResponse.json({ success: true });
}
