import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { requireAdmin } from "@/lib/auth";
import { writeAuditLog } from "@/lib/auditLog";
import { z } from "zod";

const productSchema = z.object({
  slug: z.string().trim().min(2).max(40).regex(/^[a-z0-9-]+$/),
  name: z.string().trim().min(2).max(60),
  likeAmount: z.number().int().positive(),
  priceIdr: z.number().int().min(0),
  isFree: z.boolean().default(false),
  isActive: z.boolean().default(true),
  isPopular: z.boolean().default(false),
  sortOrder: z.number().int().default(0),
  processingTimeLabel: z.string().max(60).optional(),
  description: z.string().max(300).optional(),
  freeCooldownHours: z.number().int().positive().optional(),
  freeMaxClaimsPerUid: z.number().int().min(0).optional(),
  freeMaxClaimsPerPeriod: z.number().int().min(0).optional()
});

export async function GET() {
  const { unauthorized } = await requireAdmin();
  if (unauthorized) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data, error } = await supabaseAdmin
    .from("products")
    .select("*")
    .order("sort_order", { ascending: true });

  if (error) return NextResponse.json({ error: "Gagal memuat produk." }, { status: 500 });

  return NextResponse.json({ products: data });
}

export async function POST(request) {
  const { session, unauthorized } = await requireAdmin();
  if (unauthorized) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Body tidak valid." }, { status: 400 });
  }

  const parsed = productSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message || "Input tidak valid." },
      { status: 400 }
    );
  }

  const v = parsed.data;

  const { data, error } = await supabaseAdmin
    .from("products")
    .insert({
      slug: v.slug,
      name: v.name,
      like_amount: v.likeAmount,
      price_idr: v.isFree ? 0 : v.priceIdr,
      is_free: v.isFree,
      is_active: v.isActive,
      is_popular: v.isPopular,
      sort_order: v.sortOrder,
      processing_time_label: v.processingTimeLabel || null,
      description: v.description || null,
      free_cooldown_hours: v.freeCooldownHours ?? 24,
      free_max_claims_per_uid: v.freeMaxClaimsPerUid ?? 1,
      free_max_claims_per_period: v.freeMaxClaimsPerPeriod ?? 1
    })
    .select()
    .single();

  if (error) {
    if (error.code === "23505") {
      return NextResponse.json({ error: "Slug produk sudah digunakan." }, { status: 409 });
    }
    return NextResponse.json({ error: "Gagal membuat produk." }, { status: 500 });
  }

  await writeAuditLog({
    actor: session.username,
    action: "product.created",
    targetType: "product",
    targetId: data.id,
    before: null,
    after: data
  });

  return NextResponse.json({ product: data });
}
