import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { requireAdmin } from "@/lib/auth";
import { sendToFulfillment } from "@/lib/fulfillment";
import { writeAuditLog } from "@/lib/auditLog";

export async function POST(_request, { params }) {
  const { session, unauthorized } = await requireAdmin();
  if (unauthorized) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data: order, error } = await supabaseAdmin
    .from("orders")
    .select("*")
    .eq("id", params.id)
    .maybeSingle();

  if (error || !order) {
    return NextResponse.json({ error: "Order tidak ditemukan." }, { status: 404 });
  }

  if (!order.is_free && order.payment_status !== "PAID") {
    return NextResponse.json(
      { error: "Order berbayar ini belum lunas, tidak bisa dikirim ke fulfillment." },
      { status: 400 }
    );
  }

  const job = await sendToFulfillment(order);

  await writeAuditLog({
    actor: session.username,
    action: "order.fulfillment_retried",
    targetType: "order",
    targetId: order.order_id,
    before: { orderStatus: order.order_status },
    after: { jobStatus: job?.status }
  });

  const { data: refreshed } = await supabaseAdmin
    .from("orders")
    .select("*")
    .eq("id", params.id)
    .single();

  return NextResponse.json({ order: refreshed, job });
}
