import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { requireAdmin } from "@/lib/auth";
import { writeAuditLog } from "@/lib/auditLog";
import { z } from "zod";

export async function GET(_request, { params }) {
  const { unauthorized } = await requireAdmin();
  if (unauthorized) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data: order, error } = await supabaseAdmin
    .from("orders")
    .select("*, products(name, like_amount), payments(*), fulfillment_jobs(*)")
    .eq("id", params.id)
    .maybeSingle();

  if (error || !order) {
    return NextResponse.json({ error: "Order tidak ditemukan." }, { status: 404 });
  }

  const { data: webhookEvents } = await supabaseAdmin
    .from("webhook_events")
    .select("*")
    .eq("order_id", params.id)
    .order("received_at", { ascending: false });

  return NextResponse.json({ order, webhookEvents: webhookEvents || [] });
}

// Only order_status may be changed directly by an admin, and never to PAID
// payment status — that field is exclusively controlled by the verified
// webhook handler, per spec ("admin tidak boleh mengubah payment menjadi
// PAID secara sembarangan tanpa audit log" — here we simply never allow it).
const patchSchema = z.object({
  orderStatus: z.enum(["WAITING_PAYMENT", "PROCESSING", "COMPLETED", "FAILED", "CANCELLED"])
});

export async function PATCH(request, { params }) {
  const { session, unauthorized } = await requireAdmin();
  if (unauthorized) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Body tidak valid." }, { status: 400 });
  }

  const parsed = patchSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Status tidak valid." }, { status: 400 });
  }

  const { data: before } = await supabaseAdmin
    .from("orders")
    .select("order_status")
    .eq("id", params.id)
    .maybeSingle();

  if (!before) return NextResponse.json({ error: "Order tidak ditemukan." }, { status: 404 });

  const { data: after, error } = await supabaseAdmin
    .from("orders")
    .update({ order_status: parsed.data.orderStatus })
    .eq("id", params.id)
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: "Gagal memperbarui order." }, { status: 500 });
  }

  await writeAuditLog({
    actor: session.username,
    action: "order.status_changed",
    targetType: "order",
    targetId: after.order_id,
    before: { orderStatus: before.order_status },
    after: { orderStatus: after.order_status }
  });

  return NextResponse.json({ order: after });
}
