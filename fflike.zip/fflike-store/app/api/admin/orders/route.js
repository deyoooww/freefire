import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { requireAdmin } from "@/lib/auth";

export async function GET(request) {
  const { unauthorized } = await requireAdmin();
  if (unauthorized) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const search = searchParams.get("search")?.trim();
  const orderStatus = searchParams.get("orderStatus");
  const paymentStatus = searchParams.get("paymentStatus");
  const sortBy = searchParams.get("sortBy") || "created_at";
  const sortDir = searchParams.get("sortDir") === "asc";
  const page = Math.max(1, parseInt(searchParams.get("page") || "1", 10));
  const pageSize = Math.min(100, parseInt(searchParams.get("pageSize") || "20", 10));

  let query = supabaseAdmin
    .from("orders")
    .select("id, order_id, uid, nickname, quantity, amount, is_free, payment_status, order_status, created_at, products(name)", {
      count: "exact"
    });

  if (search) {
    query = query.or(`order_id.ilike.%${search}%,uid.ilike.%${search}%,nickname.ilike.%${search}%`);
  }
  if (orderStatus) query = query.eq("order_status", orderStatus);
  if (paymentStatus) query = query.eq("payment_status", paymentStatus);

  const allowedSort = ["created_at", "amount", "quantity"];
  query = query.order(allowedSort.includes(sortBy) ? sortBy : "created_at", { ascending: sortDir });

  const from = (page - 1) * pageSize;
  query = query.range(from, from + pageSize - 1);

  const { data, error, count } = await query;

  if (error) {
    console.error("[GET /api/admin/orders]", error);
    return NextResponse.json({ error: "Gagal memuat daftar pesanan." }, { status: 500 });
  }

  return NextResponse.json({
    orders: (data || []).map((o) => ({
      id: o.id,
      orderId: o.order_id,
      uid: o.uid,
      nickname: o.nickname,
      product: o.products?.name || "-",
      quantity: o.quantity,
      amount: o.amount,
      isFree: o.is_free,
      paymentStatus: o.payment_status,
      orderStatus: o.order_status,
      createdAt: o.created_at
    })),
    pagination: { page, pageSize, total: count || 0 }
  });
}
