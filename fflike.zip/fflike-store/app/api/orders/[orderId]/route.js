import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { orderIdParamSchema } from "@/lib/validators";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";

export async function GET(request, { params }) {
  const ip = getClientIp(request);
  const rl = checkRateLimit(`track-order:${ip}`, 30, 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json({ error: "Terlalu banyak permintaan." }, { status: 429 });
  }

  const parsed = orderIdParamSchema.safeParse(params.orderId);
  if (!parsed.success) {
    return NextResponse.json({ error: "Format Order ID tidak valid." }, { status: 400 });
  }

  const { data: order, error } = await supabaseAdmin
    .from("orders")
    .select("order_id, uid, nickname, quantity, amount, is_free, payment_status, order_status, created_at, updated_at, products(name)")
    .eq("order_id", parsed.data)
    .maybeSingle();

  if (error) {
    console.error("[GET /api/orders/:orderId]", error);
    return NextResponse.json({ error: "Terjadi kesalahan pada server." }, { status: 500 });
  }

  if (!order) {
    return NextResponse.json({ error: "Order ID tidak ditemukan." }, { status: 404 });
  }

  return NextResponse.json({
    order: {
      orderId: order.order_id,
      product: order.products?.name || "-",
      uid: maskUid(order.uid),
      nickname: order.nickname,
      quantity: order.quantity,
      amount: order.amount,
      isFree: order.is_free,
      paymentStatus: order.payment_status,
      orderStatus: order.order_status,
      createdAt: order.created_at,
      updatedAt: order.updated_at
    }
  });
}

// Show only the first 3 and last 2 digits when displaying the UID back
// publicly on the tracking page (anyone with the order id can view it).
function maskUid(uid) {
  if (uid.length <= 5) return uid;
  return `${uid.slice(0, 3)}${"*".repeat(uid.length - 5)}${uid.slice(-2)}`;
}
