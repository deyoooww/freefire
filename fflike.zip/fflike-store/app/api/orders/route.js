import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { generateOrderId } from "@/lib/orderId";
import { createOrderSchema } from "@/lib/validators";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";

export async function POST(request) {
  const ip = getClientIp(request);
  const rl = checkRateLimit(`create-order:${ip}`, 10, 10 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: "Terlalu banyak percobaan. Coba lagi beberapa menit lagi." },
      { status: 429 }
    );
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Body request tidak valid." }, { status: 400 });
  }

  const parsed = createOrderSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message || "Input tidak valid." },
      { status: 400 }
    );
  }

  const { productId, uid, nickname, note } = parsed.data;

  const { data: product, error: productError } = await supabaseAdmin
    .from("products")
    .select("*")
    .eq("id", productId)
    .eq("is_active", true)
    .maybeSingle();

  if (productError || !product) {
    return NextResponse.json({ error: "Produk tidak ditemukan atau tidak aktif." }, { status: 404 });
  }

  if (product.is_free) {
    return NextResponse.json(
      { error: "Paket gratis harus diklaim lewat endpoint klaim gratis." },
      { status: 400 }
    );
  }

  // Price and quantity are always taken from the database, never trusted
  // from the client — the request only supplies a product id.
  const amount = product.price_idr;
  const quantity = product.like_amount;

  let attempt = 0;
  let inserted = null;
  let insertError = null;

  // Retry a handful of times in the astronomically unlikely event of an
  // order_id collision (unique constraint) rather than failing the order.
  while (attempt < 3 && !inserted) {
    const orderId = generateOrderId();
    const { data, error } = await supabaseAdmin
      .from("orders")
      .insert({
        order_id: orderId,
        product_id: product.id,
        uid,
        nickname,
        note: note || null,
        quantity,
        amount,
        is_free: false,
        payment_status: "PENDING",
        order_status: "WAITING_PAYMENT",
        client_ip_hash: ip
      })
      .select()
      .single();

    if (!error) {
      inserted = data;
    } else if (error.code === "23505") {
      attempt += 1;
    } else {
      insertError = error;
      break;
    }
  }

  if (!inserted) {
    console.error("[POST /api/orders]", insertError);
    return NextResponse.json({ error: "Gagal membuat pesanan. Coba lagi." }, { status: 500 });
  }

  return NextResponse.json({
    order: {
      orderId: inserted.order_id,
      product: product.name,
      likeAmount: inserted.quantity,
      uid: inserted.uid,
      nickname: inserted.nickname,
      amount: inserted.amount,
      paymentStatus: inserted.payment_status,
      orderStatus: inserted.order_status,
      isFree: false
    }
  });
}
