import { notFound } from "next/navigation";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import Navbar from "@/components/Navbar";
import BottomNav from "@/components/BottomNav";
import CheckoutForm from "@/components/CheckoutForm";

export default async function CheckoutPage({ params }) {
  const { data: product } = await supabaseAdmin
    .from("products")
    .select("id, name, like_amount, price_idr, is_free, processing_time_label")
    .eq("id", params.productId)
    .eq("is_active", true)
    .maybeSingle();

  if (!product) notFound();

  if (product.is_free) {
    // The free package has its own dedicated flow on the homepage.
    notFound();
  }

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-xl px-6 pb-28 pt-10 md:pb-16 md:pt-16">
        <h1 className="font-display text-2xl font-semibold md:text-3xl">Checkout</h1>
        <p className="mt-1 text-sm text-ink-muted">Lengkapi data untuk melanjutkan pesanan.</p>

        <CheckoutForm product={product} />
      </main>
      <BottomNav />
    </>
  );
}
