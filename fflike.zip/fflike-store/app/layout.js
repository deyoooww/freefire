import "./globals.css";

export const metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  title: "FFLIKE STORE — Free Fire Like Service",
  description: "Layanan like Free Fire dengan paket gratis 45 like dan paket berbayar.",
  icons: { icon: "/favicon.svg" },
  openGraph: {
    title: "FFLIKE STORE — Free Fire Like Service",
    description: "Layanan like Free Fire dengan paket gratis 45 like dan paket berbayar.",
    type: "website",
    siteName: "FFLIKE STORE"
  },
  robots: { index: true, follow: true }
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <head>
        <link
          rel="preconnect"
          href="https://fonts.googleapis.com"
        />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
