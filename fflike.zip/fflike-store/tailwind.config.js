/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}"
  ],
  theme: {
    extend: {
      colors: {
        base: {
          DEFAULT: "#05070D",
          layer: "#0A0E18",
          raised: "#101526"
        },
        ion: {
          cyan: "#35E8C4",
          violet: "#7B5CFF",
          amber: "#FFB454"
        },
        ink: {
          DEFAULT: "#EDEFFB",
          muted: "#9AA3B8",
          faint: "#5C6480"
        },
        line: "rgba(255,255,255,0.08)"
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"]
      },
      backdropBlur: {
        glass: "20px"
      },
      boxShadow: {
        glow: "0 0 40px -10px rgba(123,92,255,0.45)",
        glowCyan: "0 0 40px -10px rgba(53,232,196,0.4)"
      },
      borderRadius: {
        xl2: "1.25rem"
      }
    }
  },
  plugins: []
};
