"use client";

import { useState } from "react";

const faqs = [
  {
    q: "Apa itu 45 Like Gratis?",
    a: "Paket percobaan gratis berisi 45 like untuk profil Free Fire kamu, tanpa pembayaran sama sekali."
  },
  {
    q: "Bagaimana cara klaim?",
    a: "Masukkan UID Free Fire dan nickname kamu pada bagian 45 Like Gratis, lalu tekan Klaim Sekarang."
  },
  {
    q: "Apakah perlu login?",
    a: "Tidak. FFLIKE STORE tidak memerlukan akun atau login sama sekali — cukup UID dan nickname."
  },
  {
    q: "Bagaimana pembayaran QRIS?",
    a: "Untuk paket berbayar, kamu akan mendapatkan kode QRIS untuk dibayar lewat aplikasi e-wallet atau m-banking mana pun."
  },
  {
    q: "Berapa lama proses?",
    a: "Sebagian besar pesanan diproses dalam hitungan menit, tergantung jumlah like dan antrean sistem."
  },
  {
    q: "Bagaimana mengecek order?",
    a: "Buka halaman Lacak Pesanan dan masukkan Order ID yang diberikan setelah pesanan dibuat."
  },
  {
    q: "Apa yang terjadi jika pembayaran gagal?",
    a: "Order akan tetap berstatus menunggu pembayaran atau gagal, dan tidak akan diproses ke sistem pengiriman like."
  }
];

export default function Faq() {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <section id="faq" className="mx-auto max-w-3xl px-6 pt-20">
      <h2 className="font-display text-2xl font-semibold md:text-3xl">FAQ</h2>

      <div className="mt-6 flex flex-col gap-2">
        {faqs.map((item, i) => {
          const open = openIndex === i;
          return (
            <div key={item.q} className="glass overflow-hidden rounded-2xl">
              <button
                onClick={() => setOpenIndex(open ? -1 : i)}
                className="flex w-full items-center justify-between px-5 py-4 text-left text-sm font-medium md:text-base"
                aria-expanded={open}
              >
                {item.q}
                <span
                  className={`ml-4 shrink-0 text-ion-violet transition-transform ${open ? "rotate-45" : ""}`}
                >
                  +
                </span>
              </button>
              <div
                className={`grid transition-all duration-300 ease-out ${
                  open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                }`}
              >
                <div className="overflow-hidden px-5 pb-4 text-sm text-ink-muted">{item.a}</div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
