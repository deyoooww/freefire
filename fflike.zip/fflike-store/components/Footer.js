export default function Footer() {
  return (
    <footer className="mx-auto max-w-6xl px-6 pb-28 pt-16 md:pb-16">
      <div className="glass rounded-2xl px-6 py-8">
        <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
          <div>
            <span className="font-display text-lg font-semibold">
              FFLIKE <span className="text-ion-violet">STORE</span>
            </span>
            <p className="mt-2 max-w-sm text-sm text-ink-muted">
              Layanan like Free Fire cepat, simpel, dan mudah dipesan — tanpa akun,
              tanpa ribet.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-8 text-sm text-ink-muted sm:grid-cols-3">
            <div className="flex flex-col gap-2">
              <span className="text-ink-faint">Navigasi</span>
              <a href="/#packages" className="hover:text-ink">Paket</a>
              <a href="/order" className="hover:text-ink">Lacak Pesanan</a>
              <a href="/#faq" className="hover:text-ink">FAQ</a>
            </div>
            <div className="flex flex-col gap-2">
              <span className="text-ink-faint">Admin</span>
              <a href="/admin/login" className="hover:text-ink">Masuk Admin</a>
            </div>
          </div>
        </div>

        <div className="mt-8 border-t border-line pt-6 text-xs leading-relaxed text-ink-faint">
          FFLIKE STORE adalah layanan pihak ketiga yang independen dan{" "}
          <strong className="text-ink-muted">tidak berafiliasi, tidak disponsori, dan bukan
          website resmi</strong> dari Garena atau Free Fire. Seluruh nama dan merek dagang
          terkait adalah milik pemiliknya masing-masing dan digunakan hanya untuk tujuan
          identifikasi layanan.
        </div>
      </div>
    </footer>
  );
}
