"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const items = [
  { href: "/", label: "Home", icon: HomeIcon },
  { href: "/#packages", label: "Products", icon: PackageIcon },
  { href: "/order", label: "Orders", icon: OrderIcon },
  { href: "/#faq", label: "Help", icon: HelpIcon }
];

export default function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="safe-bottom glass fixed inset-x-3 bottom-3 z-40 rounded-2xl md:hidden">
      <ul className="grid grid-cols-4">
        {items.map(({ href, label, icon: Icon }) => {
          const active = href === "/" ? pathname === "/" : pathname.startsWith(href.split("#")[0]) && href.includes("#") === false;
          return (
            <li key={href}>
              <Link
                href={href}
                className={`flex flex-col items-center gap-1 py-3 text-[11px] transition ${
                  active ? "text-ion-cyan" : "text-ink-muted"
                }`}
              >
                <Icon active={active} />
                {label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

function HomeIcon({ active }) {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={active ? "#35E8C4" : "#9AA3B8"} strokeWidth="1.8">
      <path d="M4 11.5 12 4l8 7.5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M6 10v9h12v-9" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function PackageIcon({ active }) {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={active ? "#35E8C4" : "#9AA3B8"} strokeWidth="1.8">
      <path d="M3.5 8 12 4l8.5 4-8.5 4-8.5-4Z" strokeLinejoin="round" />
      <path d="M3.5 8v8l8.5 4 8.5-4V8" strokeLinejoin="round" />
      <path d="M12 12v8" />
    </svg>
  );
}
function OrderIcon({ active }) {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={active ? "#35E8C4" : "#9AA3B8"} strokeWidth="1.8">
      <rect x="4.5" y="3.5" width="15" height="17" rx="2" />
      <path d="M8 8h8M8 12h8M8 16h5" strokeLinecap="round" />
    </svg>
  );
}
function HelpIcon({ active }) {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={active ? "#35E8C4" : "#9AA3B8"} strokeWidth="1.8">
      <circle cx="12" cy="12" r="8.5" />
      <path d="M9.7 9.3a2.3 2.3 0 1 1 3.4 2c-.8.5-1.1.9-1.1 1.9" strokeLinecap="round" />
      <circle cx="12" cy="16.3" r="0.4" fill={active ? "#35E8C4" : "#9AA3B8"} />
    </svg>
  );
}
