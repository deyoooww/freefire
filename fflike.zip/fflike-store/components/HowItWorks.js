const steps = [
  { n: "01", title: "Pilih paket", desc: "Mulai dari 45 Like gratis atau paket berbayar sesuai kebutuhan." },
  { n: "02", title: "Masukkan UID", desc: "Isi UID Free Fire dan nickname kamu, tanpa perlu login atau daftar." },
  { n: "03", title: "Bayar dengan QRIS", desc: "Untuk paket berbayar, scan QRIS dan pembayaran diverifikasi otomatis." },
  { n: "04", title: "Pesanan diproses", desc: "Sistem mengirim pesanan ke layanan pengiriman like secara otomatis." },
  { n: "05", title: "Like selesai dikirim", desc: "Status berubah menjadi selesai, dan bisa dicek kapan saja lewat Order ID." }
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="mx-auto max-w-6xl px-6 pt-20">
      <h2 className="font-display text-2xl font-semibold md:text-3xl">Cara Kerja</h2>

      <ol className="mt-6 grid gap-3 md:grid-cols-5">
        {steps.map((s, i) => (
          <li key={s.n} className="glass rounded-2xl p-5">
            <span className="mono-data text-ion-violet/80">{s.n}</span>
            <p className="mt-3 font-display text-base font-semibold">{s.title}</p>
            <p className="mt-1.5 text-sm text-ink-muted">{s.desc}</p>
            {i === 2 && (
              <p className="mt-2 text-xs text-ink-faint">
                *Langkah ini dilewati untuk paket 45 Like gratis.
              </p>
            )}
          </li>
        ))}
      </ol>
    </section>
  );
}
