"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

function formatIdr(amount) {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(
    amount
  );
}

export default function CheckoutForm({ product }) {
  const router = useRouter();
  const [uid, setUid] = useState("");
  const [nickname, setNickname] = useState("");
  const [note, setNote] = useState("");
  const [step, setStep] = useState("form"); // form | review | submitting | error
  const [error, setError] = useState(null);

  function handleReview(e) {
    e.preventDefault();
    if (!uid.trim() || !nickname.trim()) return;
    setStep("review");
  }

  async function handleConfirm() {
    setStep("submitting");
    setError(null);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId: product.id, uid, nickname, note })
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Gagal membuat pesanan.");
        setStep("review");
        return;
      }

      router.push(`/order/${data.order.orderId}?justCreated=1`);
    } catch {
      setError("Tidak bisa terhubung ke server.");
      setStep("review");
    }
  }

  if (step === "review" || step === "submitting") {
    return (
      <div className="mt-8">
        <div className="glass rounded-2xl p-6">
          <h2 className="font-display text-lg font-semibold">Ringkasan Pesanan</h2>
          <dl className="mt-4 flex flex-col gap-3 text-sm">
            <Row label="Produk" value={product.name} />
            <Row label="Jumlah Like" value={`${product.like_amount.toLocaleString("id-ID")} like`} />
            <Row label="UID" value={uid} mono />
            <Row label="Nickname" value={nickname} />
            {note && <Row label="Catatan" value={note} />}
            <Row label="Harga" value={formatIdr(product.price_idr)} />
            <div className="my-1 border-t border-line" />
            <Row label="Total" value={formatIdr(product.price_idr)} strong />
          </dl>

          {error && (
            <p className="mt-4 rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>
          )}

          <div className="mt-6 flex gap-3">
            <button
              onClick={() => setStep("form")}
              disabled={step === "submitting"}
              className="glass btn-press flex-1 rounded-xl px-4 py-3 text-sm font-semibold disabled:opacity-50"
            >
              Ubah Data
            </button>
            <button
              onClick={handleConfirm}
              disabled={step === "submitting"}
              className="btn-press flex-1 rounded-xl bg-ion-violet px-4 py-3 text-sm font-semibold text-white transition hover:brightness-110 disabled:opacity-60"
            >
              {step === "submitting" ? "Membuat pesanan..." : "Buat Pesanan"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleReview} className="mt-8 flex flex-col gap-4">
      <div className="glass rounded-2xl p-5">
        <p className="mono-data font-display text-lg font-semibold">
          {product.like_amount.toLocaleString("id-ID")} Like
        </p>
        <p className="text-gradient-violet mt-1 font-display text-2xl font-semibold">
          {formatIdr(product.price_idr)}
        </p>
        {product.processing_time_label && (
          <p className="mt-1 text-xs text-ink-faint">Estimasi proses: {product.processing_time_label}</p>
        )}
      </div>

      <Field label="UID Free Fire" value={uid} onChange={setUid} placeholder="Contoh: 123456789" inputMode="numeric" required />
      <Field label="Nickname" value={nickname} onChange={setNickname} placeholder="Nickname in-game kamu" required />
      <Field label="Catatan (opsional)" value={note} onChange={setNote} placeholder="Contoh: tolong proses malam ini" />

      <button className="btn-press mt-2 rounded-xl bg-ion-violet px-6 py-3.5 text-sm font-semibold text-white transition hover:brightness-110">
        Lanjutkan
      </button>
    </form>
  );
}

function Field({ label, value, onChange, placeholder, inputMode, required }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs text-ink-muted">{label}</span>
      <input
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        inputMode={inputMode}
        className="w-full rounded-xl border border-line bg-white/[0.03] px-4 py-3 text-sm text-ink outline-none transition placeholder:text-ink-faint focus:border-ion-violet/60"
      />
    </label>
  );
}

function Row({ label, value, mono, strong }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <dt className="text-ink-muted">{label}</dt>
      <dd className={`text-right ${mono ? "mono-data" : ""} ${strong ? "font-display text-base font-semibold text-ink" : "text-ink"}`}>
        {value}
      </dd>
    </div>
  );
}
