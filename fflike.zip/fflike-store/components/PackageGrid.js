import Link from "next/link";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

function formatIdr(amount) {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(
    amount
  );
}

export default async function PackageGrid() {
  let products = [];
  try {
    const { data } = await supabaseAdmin
      .from("products")
      .select("id, slug, name, like_amount, price_idr, is_free, is_popular, processing_time_label, description")
      .eq("is_active", true)
      .eq("is_free", false)
      .order("sort_order", { ascending: true });
    products = data || [];
  } catch {
    products = [];
  }

  return (
    <section id="packages" className="mx-auto max-w-6xl px-6 pt-20">
      <div className="flex items-end justify-between">
        <h2 className="font-display text-2xl font-semibold md:text-3xl">Like Packages</h2>
      </div>

      {products.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-4">
          {products.map((p) => (
            <div
              key={p.id}
              className="glass glass-glow-violet relative flex flex-col justify-between rounded-2xl p-4 md:p-6"
            >
              {p.is_popular && (
                <span className="absolute right-4 top-4 rounded-full bg-ion-violet/20 px-2.5 py-1 text-[10px] font-semibold text-ion-violet">
                  POPULER
                </span>
              )}

              <div>
                <p className="mono-data font-display text-lg font-semibold md:text-xl">
                  {p.like_amount.toLocaleString("id-ID")} Like
                </p>
                <p className="mt-1 text-xs text-ink-faint">
                  {p.processing_time_label || "Diproses cepat"}
                </p>
              </div>

              <div className="mt-6">
                <p className="text-gradient-violet font-display text-xl font-semibold md:text-2xl">
                  {formatIdr(p.price_idr)}
                </p>
                <Link
                  href={`/checkout/${p.id}`}
                  className="btn-press mt-3 block rounded-xl bg-ion-violet px-4 py-2.5 text-center text-sm font-semibold text-white transition hover:brightness-110"
                >
                  Pesan
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function EmptyState() {
  return (
    <div className="glass mt-6 rounded-2xl px-6 py-10 text-center text-sm text-ink-muted">
      Belum ada paket berbayar yang aktif saat ini. Cek kembali sebentar lagi.
    </div>
  );
}
