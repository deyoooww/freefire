"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function OrderTrackerWidget() {
  const router = useRouter();
  const [orderId, setOrderId] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    const trimmed = orderId.trim().toUpperCase();
    if (!trimmed) return;
    router.push(`/order/${trimmed}`);
  }

  return (
    <section id="order-tracking" className="mx-auto max-w-6xl px-6 pt-20">
      <div className="glass flex flex-col items-center gap-4 rounded-2xl p-6 text-center md:flex-row md:justify-between md:text-left">
        <div>
          <h3 className="font-display text-lg font-semibold md:text-xl">Lacak Pesananmu</h3>
          <p className="mt-1 text-sm text-ink-muted">Masukkan Order ID untuk melihat status terbaru.</p>
        </div>
        <form onSubmit={handleSubmit} className="flex w-full max-w-sm gap-2">
          <input
            value={orderId}
            onChange={(e) => setOrderId(e.target.value)}
            placeholder="FFL-20260912-8X4K2"
            className="mono-data w-full rounded-xl border border-line bg-white/[0.03] px-4 py-3 text-sm outline-none placeholder:text-ink-faint focus:border-ion-violet/60"
          />
          <button className="btn-press shrink-0 rounded-xl bg-ion-violet px-5 py-3 text-sm font-semibold text-white transition hover:brightness-110">
            Cek
          </button>
        </form>
      </div>
    </section>
  );
}
