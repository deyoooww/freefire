import Link from "next/link";

const links = [
  { href: "/#packages", label: "Paket" },
  { href: "/#how-it-works", label: "Cara Kerja" },
  { href: "/order", label: "Lacak Pesanan" },
  { href: "/#faq", label: "FAQ" }
];

export default function Navbar() {
  return (
    <header className="sticky top-0 z-40 hidden md:block">
      <div className="mx-auto max-w-6xl px-6 pt-4">
        <nav className="glass flex items-center justify-between rounded-2xl px-6 py-3">
          <Link href="/" className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-ion-cyan" />
            <span className="font-display text-lg font-semibold tracking-tight">
              FFLIKE <span className="text-ion-violet">STORE</span>
            </span>
          </Link>

          <div className="flex items-center gap-8 text-sm text-ink-muted">
            {links.map((l) => (
              <Link key={l.href} href={l.href} className="transition hover:text-ink">
                {l.label}
              </Link>
            ))}
          </div>

          <Link
            href="/#free-claim"
            className="btn-press rounded-xl bg-ion-violet px-4 py-2 text-sm font-semibold text-white shadow-glow transition hover:brightness-110"
          >
            Klaim 45 Like
          </Link>
        </nav>
      </div>
    </header>
  );
}
