"use client";

import { useRouter } from "next/navigation";

export default function AdminLogoutButton({ compact }) {
  const router = useRouter();

  async function handleLogout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.push("/admin/login");
    router.refresh();
  }

  return (
    <button
      onClick={handleLogout}
      className={
        compact
          ? "rounded-lg bg-white/[0.06] px-3 py-1.5 text-xs text-ink-muted"
          : "w-full rounded-xl px-3 py-2 text-left text-sm text-ink-muted transition hover:bg-white/[0.06] hover:text-red-300"
      }
    >
      Keluar
    </button>
  );
}
