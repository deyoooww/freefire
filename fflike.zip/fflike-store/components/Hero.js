import Link from "next/link";

export default function Hero() {
  return (
    <section className="relative mx-auto max-w-6xl px-6 pt-16 md:pt-24">
      <div className="zone-rings" aria-hidden="true" />

      <div className="relative flex flex-col items-center text-center">
        <span className="glass rounded-full px-4 py-1.5 text-xs text-ink-muted">
          45 Like pertama gratis, tanpa kartu · tanpa akun
        </span>

        <h1 className="mt-6 max-w-3xl font-display text-4xl font-semibold leading-[1.08] tracking-tight md:text-6xl">
          Boost your Free Fire profile
        </h1>

        <p className="mt-5 max-w-lg text-balance text-base text-ink-muted md:text-lg">
          Layanan like Free Fire cepat, simpel, dan mudah dipesan.
        </p>

        <div className="mt-9 flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
          <Link
            href="#free-claim"
            className="btn-press glass-glow-cyan rounded-xl bg-gradient-to-b from-ion-cyan to-[#17B79A] px-7 py-3.5 text-center text-sm font-semibold text-[#03211B]"
          >
            Klaim 45 Like Gratis
          </Link>
          <Link
            href="#packages"
            className="glass btn-press rounded-xl px-7 py-3.5 text-center text-sm font-semibold text-ink transition hover:bg-white/[0.06]"
          >
            Lihat Paket
          </Link>
        </div>

        <dl className="mt-16 grid w-full max-w-2xl grid-cols-3 gap-3">
          {[
            { value: "45", label: "Free Like" },
            { value: "< 15m", label: "Fast Process" },
            { value: "QRIS", label: "Secure Payment" }
          ].map((stat) => (
            <div key={stat.label} className="glass rounded-2xl px-3 py-5">
              <dt className="mono-data font-display text-xl font-semibold text-gradient-violet md:text-2xl">
                {stat.value}
              </dt>
              <dd className="mt-1 text-[11px] uppercase tracking-wide text-ink-faint md:text-xs">
                {stat.label}
              </dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
