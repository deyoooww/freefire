"use client";

import { useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";

function formatIdr(amount) {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(
    amount
  );
}

const POLL_INTERVAL_MS = 5000;
const ACTIVE_STATUSES = new Set(["WAITING_PAYMENT", "PROCESSING"]);

export default function OrderStatusView({ orderId }) {
  const searchParams = useSearchParams();
  const justCreated = searchParams.get("justCreated") === "1";

  const [order, setOrder] = useState(null);
  const [payment, setPayment] = useState(null);
  const [loadState, setLoadState] = useState("loading"); // loading | ready | notfound | error
  const [refreshing, setRefreshing] = useState(false);
  const [paymentError, setPaymentError] = useState(null);
  const timerRef = useRef(null);

  async function fetchOrder({ silent } = {}) {
    if (silent) setRefreshing(true);
    try {
      const res = await fetch(`/api/orders/${orderId}`, { cache: "no-store" });
      const data = await res.json();

      if (res.status === 404) {
        setLoadState("notfound");
        return;
      }
      if (!res.ok) {
        setLoadState("error");
        return;
      }

      setOrder(data.order);
      setLoadState("ready");
    } catch {
      setLoadState((prev) => (prev === "ready" ? prev : "error"));
    } finally {
      if (silent) setRefreshing(false);
    }
  }

  useEffect(() => {
    fetchOrder();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderId]);

  useEffect(() => {
    if (!order) return undefined;
    if (!ACTIVE_STATUSES.has(order.orderStatus)) return undefined;

    timerRef.current = setInterval(() => {
      fetchOrder({ silent: true });
    }, POLL_INTERVAL_MS);

    return () => clearInterval(timerRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [order?.orderStatus]);

  // Fetch/create a QRIS payment session for paid orders still awaiting payment.
  useEffect(() => {
    if (!order) return;
    if (order.isFree) return;
    if (order.orderStatus !== "WAITING_PAYMENT") return;

    let cancelled = false;
    setPaymentError(null);

    fetch("/api/payment/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ orderId: order.orderId })
    })
      .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
      .then(({ ok, data }) => {
        if (cancelled) return;
        if (!ok) {
          setPaymentError(data.error || "Gagal memuat QRIS.");
          return;
        }
        setPayment(data.payment);
      })
      .catch(() => {
        if (!cancelled) setPaymentError("Tidak bisa memuat QRIS. Coba lagi.");
      });

    return () => {
      cancelled = true;
    };
  }, [order?.orderId, order?.orderStatus, order?.isFree]);

  if (loadState === "loading") return <LoadingCard />;
  if (loadState === "notfound") return <NotFoundCard orderId={orderId} />;
  if (loadState === "error") return <ErrorCard onRetry={() => fetchOrder()} />;

  return (
    <div>
      {justCreated && (
        <div className="glass mb-4 rounded-2xl border-ion-cyan/30 px-5 py-3 text-sm text-ion-cyan">
          Pesanan berhasil dibuat. Simpan Order ID di bawah ini.
        </div>
      )}

      <div className="glass rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <h1 className="font-display text-xl font-semibold md:text-2xl">Status Pesanan</h1>
          {refreshing && <span className="text-xs text-ink-faint">Updating status...</span>}
        </div>

        <p className="mono-data mt-3 text-lg font-semibold text-gradient-violet">{order.orderId}</p>

        <dl className="mt-5 flex flex-col gap-3 text-sm">
          <Row label="Produk" value={order.product} />
          <Row label="UID" value={order.uid} mono />
          <Row label="Nickname" value={order.nickname} />
          <Row label="Jumlah Like" value={`${order.quantity.toLocaleString("id-ID")} like`} />
          <Row label="Total" value={formatIdr(order.amount)} strong />
          <div className="my-1 border-t border-line" />
          <Row label="Status Pembayaran" value={<StatusBadge value={order.paymentStatus} kind="payment" />} />
          <Row label="Status Pesanan" value={<StatusBadge value={order.orderStatus} kind="order" />} />
          <Row label="Dibuat" value={new Date(order.createdAt).toLocaleString("id-ID")} />
        </dl>
      </div>

      {!order.isFree && order.orderStatus === "WAITING_PAYMENT" && (
        <div className="glass mt-4 rounded-2xl p-6">
          <h2 className="font-display text-lg font-semibold">Lanjutkan Pembayaran</h2>
          {paymentError ? (
            <p className="mt-3 rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">{paymentError}</p>
          ) : payment ? (
            <div className="mt-4 flex flex-col items-center gap-3">
              {payment.qrImageUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={payment.qrImageUrl}
                  alt="Kode QRIS untuk pembayaran"
                  className="h-56 w-56 rounded-xl bg-white p-2"
                />
              ) : payment.qrString ? (
                <div className="rounded-xl bg-white p-4 text-center text-xs text-black">
                  QRIS string tersedia — render dengan library QR code pilihanmu
                  <p className="mono-data mt-2 break-all">{payment.qrString}</p>
                </div>
              ) : (
                <p className="text-sm text-ink-muted">Menunggu data QRIS dari payment gateway...</p>
              )}
              <p className="text-gradient-cyan font-display text-xl font-semibold">
                {formatIdr(payment.amount)}
              </p>
              {payment.expiresAt && (
                <p className="text-xs text-ink-faint">
                  Berlaku sampai {new Date(payment.expiresAt).toLocaleString("id-ID")}
                </p>
              )}
              <p className="text-center text-xs text-ink-faint">
                Status akan otomatis berubah setelah pembayaran terverifikasi. Jangan tutup halaman ini.
              </p>
            </div>
          ) : (
            <QrSkeleton />
          )}
        </div>
      )}

      <OrderTimeline order={order} />
    </div>
  );
}

function Row({ label, value, mono, strong }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <dt className="text-ink-muted">{label}</dt>
      <dd className={`text-right ${mono ? "mono-data" : ""} ${strong ? "font-display text-base font-semibold text-ink" : "text-ink"}`}>
        {value}
      </dd>
    </div>
  );
}

const paymentLabels = {
  PENDING: "Menunggu",
  PAID: "Lunas",
  FAILED: "Gagal",
  EXPIRED: "Kedaluwarsa",
  REFUNDED: "Dikembalikan",
  NOT_REQUIRED: "Tidak Diperlukan"
};
const orderLabels = {
  WAITING_PAYMENT: "Menunggu Pembayaran",
  PROCESSING: "Diproses",
  COMPLETED: "Selesai",
  FAILED: "Gagal",
  CANCELLED: "Dibatalkan"
};
const toneMap = {
  PAID: "cyan",
  COMPLETED: "cyan",
  NOT_REQUIRED: "cyan",
  PROCESSING: "violet",
  PENDING: "violet",
  WAITING_PAYMENT: "violet",
  FAILED: "red",
  EXPIRED: "red",
  CANCELLED: "red",
  REFUNDED: "amber"
};

function StatusBadge({ value, kind }) {
  const label = (kind === "payment" ? paymentLabels : orderLabels)[value] || value;
  const tone = toneMap[value] || "violet";
  const toneClasses = {
    cyan: "bg-ion-cyan/15 text-ion-cyan",
    violet: "bg-ion-violet/15 text-ion-violet",
    red: "bg-red-500/15 text-red-300",
    amber: "bg-ion-amber/15 text-ion-amber"
  };
  return (
    <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${toneClasses[tone]}`}>{label}</span>
  );
}

function OrderTimeline({ order }) {
  const steps = order.isFree
    ? ["ORDER CREATED", "PROCESSING", "COMPLETED"]
    : ["ORDER CREATED", "PAYMENT RECEIVED", "PROCESSING", "COMPLETED"];

  const failed = order.orderStatus === "FAILED" || order.orderStatus === "CANCELLED";

  let currentIndex = 0;
  if (order.isFree) {
    if (order.orderStatus === "PROCESSING") currentIndex = 1;
    if (order.orderStatus === "COMPLETED") currentIndex = 2;
  } else {
    if (order.paymentStatus === "PAID") currentIndex = 1;
    if (order.orderStatus === "PROCESSING") currentIndex = 2;
    if (order.orderStatus === "COMPLETED") currentIndex = 3;
  }

  return (
    <div className="glass mt-4 rounded-2xl p-6">
      <h2 className="font-display text-lg font-semibold">Timeline</h2>
      <ol className="mt-4 flex flex-col gap-4">
        {steps.map((label, i) => {
          const done = !failed && i <= currentIndex;
          const isFailedStep = failed && i === currentIndex + 1;
          return (
            <li key={label} className="flex items-center gap-3">
              <span
                className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[11px] font-semibold ${
                  isFailedStep
                    ? "bg-red-500/20 text-red-300"
                    : done
                    ? "bg-ion-cyan/20 text-ion-cyan"
                    : "bg-white/[0.06] text-ink-faint"
                }`}
              >
                {isFailedStep ? "!" : done ? "✓" : i + 1}
              </span>
              <span className={done ? "text-ink" : "text-ink-faint"}>{label}</span>
            </li>
          );
        })}
        {failed && (
          <li className="flex items-center gap-3">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500/20 text-[11px] font-semibold text-red-300">
              !
            </span>
            <span className="text-red-300">
              {order.orderStatus === "CANCELLED" ? "CANCELLED" : "FAILED"}
            </span>
          </li>
        )}
      </ol>
    </div>
  );
}

function LoadingCard() {
  return (
    <div className="glass rounded-2xl p-6">
      <div className="skeleton h-6 w-40 rounded-lg" />
      <div className="skeleton mt-4 h-4 w-full rounded-lg" />
      <div className="skeleton mt-2 h-4 w-3/4 rounded-lg" />
      <div className="skeleton mt-2 h-4 w-1/2 rounded-lg" />
    </div>
  );
}

function QrSkeleton() {
  return <div className="skeleton mx-auto mt-4 h-56 w-56 rounded-xl" />;
}

function NotFoundCard({ orderId }) {
  return (
    <div className="glass rounded-2xl p-6 text-center">
      <h1 className="font-display text-xl font-semibold">Order Tidak Ditemukan</h1>
      <p className="mono-data mt-2 text-sm text-ink-muted">{orderId}</p>
      <p className="mt-3 text-sm text-ink-muted">
        Pastikan Order ID yang kamu masukkan sudah benar, lalu coba lagi.
      </p>
    </div>
  );
}

function ErrorCard({ onRetry }) {
  return (
    <div className="glass rounded-2xl p-6 text-center">
      <h1 className="font-display text-xl font-semibold">Terjadi Kesalahan</h1>
      <p className="mt-2 text-sm text-ink-muted">Tidak bisa memuat status pesanan saat ini.</p>
      <button
        onClick={onRetry}
        className="btn-press mt-4 rounded-xl bg-ion-violet px-5 py-2.5 text-sm font-semibold text-white"
      >
        Coba Lagi
      </button>
    </div>
  );
}
