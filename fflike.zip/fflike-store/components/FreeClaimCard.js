"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function FreeClaimCard() {
  const router = useRouter();
  const [uid, setUid] = useState("");
  const [nickname, setNickname] = useState("");
  const [status, setStatus] = useState("idle"); // idle | loading | error
  const [error, setError] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus("loading");
    setError(null);

    try {
      const res = await fetch("/api/free/claim", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ uid, nickname })
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Klaim gagal. Coba lagi.");
        setStatus("error");
        return;
      }

      router.push(`/order/${data.order.orderId}?justCreated=1`);
    } catch {
      setError("Tidak bisa terhubung ke server. Periksa koneksi kamu.");
      setStatus("error");
    }
  }

  return (
    <section id="free-claim" className="mx-auto max-w-6xl px-6 pt-16">
      <div className="glass glass-glow-cyan relative overflow-hidden rounded-3xl p-6 md:p-10">
        <span className="absolute right-6 top-6 rounded-full bg-ion-cyan/15 px-3 py-1 text-[11px] font-semibold text-ion-cyan">
          FREE
        </span>

        <div className="grid gap-8 md:grid-cols-2 md:items-center">
          <div>
            <h2 className="font-display text-2xl font-semibold md:text-3xl">
              45 Like Gratis
            </h2>
            <p className="mt-2 text-sm text-ink-muted md:text-base">
              Coba layanan kami tanpa pembayaran.
            </p>
            <p className="mono-data mt-6 text-3xl font-semibold text-gradient-cyan">
              Rp0
            </p>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-3">
            <Field
              label="UID Free Fire"
              value={uid}
              onChange={setUid}
              placeholder="Contoh: 123456789"
              inputMode="numeric"
            />
            <Field
              label="Nickname"
              value={nickname}
              onChange={setNickname}
              placeholder="Nickname in-game kamu"
            />

            {error && (
              <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={status === "loading"}
              className="btn-press mt-2 rounded-xl bg-gradient-to-b from-ion-cyan to-[#17B79A] px-6 py-3 text-sm font-semibold text-[#03211B] transition hover:brightness-110 disabled:opacity-60"
            >
              {status === "loading" ? "Memproses..." : "Klaim Sekarang"}
            </button>
            <p className="text-center text-xs text-ink-faint">
              1 klaim per UID setiap periode cooldown yang ditentukan admin.
            </p>
          </form>
        </div>
      </div>
    </section>
  );
}

function Field({ label, value, onChange, placeholder, inputMode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs text-ink-muted">{label}</span>
      <input
        required
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        inputMode={inputMode}
        className="w-full rounded-xl border border-line bg-white/[0.03] px-4 py-3 text-sm text-ink outline-none transition placeholder:text-ink-faint focus:border-ion-cyan/60"
      />
    </label>
  );
}
